# Google Play listing

## English
**Title (30):** GhiatVPN – Secure WireGuard
**Short (80):** Fast, private VPN powered by WireGuard. No ads, no accounts.
**Full:**
GhiatVPN connects you through WireGuard, a modern, fast and secure VPN protocol.
• One-tap connect • Multiple servers • No ads, no sign-up, no analytics
• Your configs stay on your device
Note: GhiatVPN uses Android's VPN service to route your traffic through the server you choose.

## العربية
**العنوان:** GhiatVPN – اتصال آمن
**وصف قصير:** VPN سريع وخاص بتقنية WireGuard. بلا إعلانات ولا حسابات.
**الوصف:**
يوصلك GhiatVPN عبر WireGuard، بروتوكول VPN حديث وسريع وآمن.
• اتصال بضغطة واحدة • عدة سيرفرات • بلا إعلانات ولا تسجيل ولا تحليلات
• إعداداتك تبقى على جهازك
ملاحظة: يستخدم التطبيق خدمة VPN في أندرويد لتمرير حركة الإنترنت عبر السيرفر الذي تختاره.

## Graphics needed
Icon 512x512 PNG, feature graphic 1024x500, at least 2 phone screenshots.
