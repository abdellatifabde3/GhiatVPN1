# GhiatVPN release rules (R8)
# WireGuard tunnel library: native (JNI) bridge and config model must keep names.
-keep class com.wireguard.android.backend.** { *; }
-keep class com.wireguard.config.** { *; }
-keep class com.wireguard.crypto.** { *; }
-keepclasseswithmembernames class * { native <methods>; }
-dontwarn com.wireguard.**

# Google code scanner (ML Kit) ships its own consumer rules; nothing extra needed.
# Keep line numbers for readable Play Console crash reports.
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile
