package com.ghiat.vpn.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Blue = Color(0xFF1565C0)
val BlueLight = Color(0xFF42A5F5)
val Bg = Color(0xFFF4F8FF)

@Composable
fun GhiatTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(primary = Blue, secondary = BlueLight, background = Bg, surface = Color.White),
        content = content
    )
}
