package com.ghiat.vpn.ui

import android.app.Activity
import android.net.VpnService
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ghiat.vpn.R
import com.ghiat.vpn.vpn.Server
import com.ghiat.vpn.vpn.ServerStore
import com.ghiat.vpn.vpn.VpnController
import com.ghiat.vpn.vpn.VpnState
import java.util.Locale
import java.util.UUID
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.codescanner.GmsBarcodeScannerOptions
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning
import com.ghiat.vpn.vpn.AppSettings

@Composable
fun HomeScreen(onOpenSettings: () -> Unit = {}) {
    val context = LocalContext.current
    val store = remember { ServerStore(context) }
    val servers = remember { mutableStateListOf<Server>().apply { addAll(store.load()) } }
    var selectedId by rememberSaveable { mutableStateOf(servers.firstOrNull()?.id) }
    var showAdd by rememberSaveable { mutableStateOf(false) }
    LaunchedEffect(Unit) { VpnController.refresh(context) }
    val state by VpnController.state.collectAsState()
    val error by VpnController.error.collectAsState()
    val stats by VpnController.stats.collectAsState()

    fun startVpn() {
        val s = servers.firstOrNull { it.id == selectedId } ?: return
        VpnController.connect(context, VpnController.withExcluded(s.conf, AppSettings(context).excluded))
    }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (it.resultCode == Activity.RESULT_OK) startVpn()
    }

    Column(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)
            .statusBarsPadding().navigationBarsPadding().padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Image(painterResource(R.drawable.ic_logo), null, Modifier.size(44.dp))
            Spacer(Modifier.width(8.dp))
            Text(stringResource(R.string.app_name), fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Blue, modifier = Modifier.weight(1f))
            Text("⚙", fontSize = 26.sp, color = Blue, modifier = Modifier.clickable { onOpenSettings() }.padding(8.dp))
        }
        Spacer(Modifier.weight(1f))

        val ring by animateColorAsState(
            when (state) { VpnState.CONNECTED -> Color(0xFF2E7D32); VpnState.CONNECTING -> BlueLight; else -> Blue }, label = "ring"
        )
        Box(
            Modifier.size(180.dp).clip(CircleShape).border(8.dp, ring, CircleShape).background(Color.White)
                .clickable {
                    when (state) {
                        VpnState.DISCONNECTED -> {
                            if (selectedId == null) showAdd = true
                            else {
                                val intent = VpnService.prepare(context)
                                if (intent != null) permLauncher.launch(intent) else startVpn()
                            }
                        }
                        VpnState.CONNECTED -> VpnController.disconnect()
                        VpnState.CONNECTING -> Unit
                    }
                },
            contentAlignment = Alignment.Center
        ) { Text("⏻", fontSize = 64.sp, color = ring) }

        Spacer(Modifier.height(16.dp))
        Text(
            stringResource(
                when (state) {
                    VpnState.DISCONNECTED -> R.string.tap_connect
                    VpnState.CONNECTING -> R.string.connecting
                    VpnState.CONNECTED -> R.string.connected
                }
            ),
            fontSize = 20.sp, fontWeight = FontWeight.SemiBold, color = ring
        )
        if (state == VpnState.CONNECTED) Text(stringResource(R.string.tap_disconnect), fontSize = 13.sp, color = Color.Gray)
        if (state == VpnState.CONNECTED) {
            Spacer(Modifier.height(10.dp))
            Text(formatDuration(stats.seconds), fontSize = 16.sp, fontWeight = FontWeight.Medium, color = Blue)
            Text("↓ ${formatSpeed(stats.rxSpeed)}    ↑ ${formatSpeed(stats.txSpeed)}", fontSize = 14.sp)
            Text("↓ ${formatBytes(stats.rx)}    ↑ ${formatBytes(stats.tx)}", fontSize = 12.sp, color = Color.Gray)
        }
        error?.let { Text(it, fontSize = 12.sp, color = Color(0xFFC62828), modifier = Modifier.padding(top = 6.dp)) }
        Spacer(Modifier.weight(1f))

        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(stringResource(R.string.choose_server), fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            TextButton(onClick = { showAdd = true }, enabled = state == VpnState.DISCONNECTED) {
                Text("+ " + stringResource(R.string.add_server))
            }
        }
        if (servers.isEmpty()) {
            Text(stringResource(R.string.no_servers), color = Color.Gray, fontSize = 13.sp, modifier = Modifier.padding(vertical = 12.dp))
        }
        LazyColumn(Modifier.heightIn(max = 220.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(servers, key = { it.id }) { s ->
                val sel = s.id == selectedId
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
                        .background(if (sel) Blue.copy(alpha = 0.12f) else Color.White)
                        .border(1.dp, if (sel) Blue else Color(0xFFE0E6F0), RoundedCornerShape(14.dp))
                        .clickable(enabled = state == VpnState.DISCONNECTED) { selectedId = s.id }
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(s.flag, fontSize = 26.sp)
                    Spacer(Modifier.width(12.dp))
                    Text(s.name, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                    if (state == VpnState.DISCONNECTED) {
                        Text("✕", color = Color.Gray, modifier = Modifier.clickable {
                            servers.remove(s); store.save(servers.toList())
                            if (selectedId == s.id) selectedId = servers.firstOrNull()?.id
                        }.padding(8.dp))
                    }
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        Text(stringResource(R.string.developer), fontSize = 12.sp, color = Color.Gray)
    }

    if (showAdd) {
        var name by remember { mutableStateOf("") }
        var conf by remember { mutableStateOf("") }
        var err by remember { mutableStateOf<String?>(null) }
        val clipboard = LocalClipboardManager.current
        val scan = {
            val opts = GmsBarcodeScannerOptions.Builder().setBarcodeFormats(Barcode.FORMAT_QR_CODE).build()
            GmsBarcodeScanning.getClient(context, opts).startScan()
                .addOnSuccessListener { b ->
                    val text = b.rawValue
                    if (text.isNullOrBlank()) err = context.getString(R.string.scan_failed)
                    else { conf = text; err = null; if (name.isBlank()) name = "Server" }
                }
                .addOnFailureListener { err = context.getString(R.string.scan_failed) }
            Unit
        }
        val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            if (uri != null) try {
                conf = context.contentResolver.openInputStream(uri)!!.use { it.readBytes().toString(Charsets.UTF_8) }
                if (name.isBlank()) name = "Server"
                err = null
            } catch (e: Exception) { err = context.getString(R.string.invalid_config) }
        }
        AlertDialog(
            onDismissRequest = { showAdd = false },
            title = { Text(stringResource(R.string.add_server)) },
            text = {
                Column {
                    OutlinedTextField(name, { name = it }, singleLine = true, label = { Text(stringResource(R.string.server_name)) })
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(conf, { conf = it }, label = { Text(stringResource(R.string.paste_config)) }, minLines = 5, maxLines = 8)
                    Row {
                        TextButton(onClick = { picker.launch("*/*") }) { Text(stringResource(R.string.import_file)) }
                        TextButton(onClick = {
                            val t = clipboard.getText()?.text
                            if (t.isNullOrBlank()) err = context.getString(R.string.clipboard_empty)
                            else { conf = t; err = null; if (name.isBlank()) name = "Server" }
                        }) { Text(stringResource(R.string.paste_clipboard)) }
                    }
                    TextButton(onClick = { scan() }) { Text(stringResource(R.string.scan_qr)) }
                    err?.let { Text(it, color = Color(0xFFC62828), fontSize = 12.sp) }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    try {
                        VpnController.validate(conf)
                        val s = Server(UUID.randomUUID().toString(), name.ifBlank { "Server" }, "🌐", conf)
                        servers.add(s); store.save(servers.toList())
                        if (selectedId == null) selectedId = s.id
                        showAdd = false
                    } catch (e: Exception) { err = context.getString(R.string.invalid_config) + ": " + (e.message ?: "") }
                }) { Text(stringResource(R.string.save)) }
            },
            dismissButton = { TextButton(onClick = { showAdd = false }) { Text(stringResource(R.string.cancel)) } }
        )
    }
}

private fun formatBytes(b: Long): String = when {
    b >= (1L shl 30) -> String.format(Locale.US, "%.2f GB", b / (1L shl 30).toDouble())
    b >= (1L shl 20) -> String.format(Locale.US, "%.1f MB", b / (1L shl 20).toDouble())
    b >= (1L shl 10) -> String.format(Locale.US, "%.0f KB", b / 1024.0)
    else -> "$b B"
}

private fun formatSpeed(b: Long) = formatBytes(b) + "/s"

private fun formatDuration(s: Long) = String.format(Locale.US, "%02d:%02d:%02d", s / 3600, (s % 3600) / 60, s % 60)
