package com.ghiat.vpn.ui

import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ghiat.vpn.R
import com.ghiat.vpn.vpn.AppSettings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private data class AppEntry(val label: String, val pkg: String)

private fun loadApps(context: Context): List<AppEntry> {
    val pm = context.packageManager
    val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(intent, 0)
        .map { AppEntry(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
        .filter { it.pkg != context.packageName }
        .distinctBy { it.pkg }
        .sortedBy { it.label.lowercase() }
}

@Composable
fun SettingsScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    BackHandler(onBack = onBack)
    val settings = remember { AppSettings(context) }
    var excluded by remember { mutableStateOf(settings.excluded) }
    var query by remember { mutableStateOf("") }
    var apps by remember { mutableStateOf<List<AppEntry>?>(null) }
    LaunchedEffect(Unit) { apps = withContext(Dispatchers.IO) { loadApps(context) } }
    val shown = apps?.filter { query.isBlank() || it.label.contains(query, true) || it.pkg.contains(query, true) }

    LazyColumn(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)
            .statusBarsPadding().navigationBarsPadding().padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = onBack) { Text("←", fontSize = 22.sp) }
                Text(stringResource(R.string.settings), fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Blue)
            }
        }
        item {
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Color.White).padding(14.dp)) {
                Text(stringResource(R.string.kill_switch_title), fontWeight = FontWeight.Bold)
                Text(stringResource(R.string.kill_switch_desc), fontSize = 13.sp, color = Color.Gray)
                TextButton(onClick = {
                    try { context.startActivity(Intent(Settings.ACTION_VPN_SETTINGS)) } catch (_: Exception) {}
                }) { Text(stringResource(R.string.open_vpn_settings)) }
            }
        }
        item {
            Column(Modifier.padding(top = 10.dp)) {
                Text(stringResource(R.string.split_title), fontWeight = FontWeight.Bold)
                Text(stringResource(R.string.split_desc), fontSize = 13.sp, color = Color.Gray)
                OutlinedTextField(
                    query, { query = it }, singleLine = true,
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                    label = { Text(stringResource(R.string.search_apps)) }
                )
            }
        }
        if (shown == null) {
            item { CircularProgressIndicator(Modifier.padding(24.dp)) }
        } else {
            items(shown, key = { it.pkg }) { app ->
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Color.White)
                        .padding(horizontal = 14.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(app.label, fontWeight = FontWeight.SemiBold)
                        Text(app.pkg, fontSize = 11.sp, color = Color.Gray)
                    }
                    Switch(checked = app.pkg in excluded, onCheckedChange = { on ->
                        excluded = if (on) excluded + app.pkg else excluded - app.pkg
                        settings.excluded = excluded
                    })
                }
            }
        }
        item { Spacer(Modifier.height(16.dp)) }
    }
}
