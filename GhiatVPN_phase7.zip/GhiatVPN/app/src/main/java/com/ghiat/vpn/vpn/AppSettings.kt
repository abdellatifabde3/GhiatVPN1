package com.ghiat.vpn.vpn

import android.content.Context

/** Non-sensitive user settings (apps that bypass the VPN). */
class AppSettings(context: Context) {
    private val prefs = context.getSharedPreferences("settings", Context.MODE_PRIVATE)

    var excluded: Set<String>
        get() = prefs.getStringSet("excluded", emptySet())?.toSet() ?: emptySet()
        set(v) { prefs.edit().putStringSet("excluded", v.toSet()).apply() }
}
