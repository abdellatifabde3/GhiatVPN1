package com.ghiat.vpn

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.ghiat.vpn.ui.GhiatTheme
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import com.ghiat.vpn.ui.HomeScreen
import com.ghiat.vpn.ui.SettingsScreen

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            GhiatTheme {
                var showSettings by rememberSaveable { mutableStateOf(false) }
                if (showSettings) SettingsScreen { showSettings = false }
                else HomeScreen(onOpenSettings = { showSettings = true })
            }
        }
    }
}
