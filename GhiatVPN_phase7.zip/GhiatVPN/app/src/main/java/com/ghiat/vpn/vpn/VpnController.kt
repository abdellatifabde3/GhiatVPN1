package com.ghiat.vpn.vpn

import android.content.Context
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.Config
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.ByteArrayInputStream

enum class VpnState { DISCONNECTED, CONNECTING, CONNECTED }

/** Live traffic numbers: totals in bytes, speeds in bytes/second, duration in seconds. */
data class Stats(val rx: Long = 0, val tx: Long = 0, val rxSpeed: Long = 0, val txSpeed: Long = 0, val seconds: Long = 0)

/** Real WireGuard tunnel through the official wireguard-android library. */
object VpnController {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var backend: GoBackend? = null
    private var statsJob: Job? = null

    private val _state = MutableStateFlow(VpnState.DISCONNECTED)
    val state: StateFlow<VpnState> = _state
    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error
    private val _stats = MutableStateFlow(Stats())
    val stats: StateFlow<Stats> = _stats

    private val tunnel = object : Tunnel {
        override fun getName() = "ghiatvpn"
        override fun onStateChange(newState: Tunnel.State) {
            setState(if (newState == Tunnel.State.UP) VpnState.CONNECTED else VpnState.DISCONNECTED)
        }
    }

    private fun setState(s: VpnState) {
        _state.value = s
        if (s == VpnState.CONNECTED) {
            if (statsJob?.isActive != true) startStats()
        } else {
            statsJob?.cancel(); statsJob = null
            _stats.value = Stats()
        }
    }

    private fun startStats() {
        statsJob = scope.launch {
            val start = System.currentTimeMillis()
            var lastRx = -1L
            var lastTx = -1L
            while (isActive) {
                try {
                    val st = backend?.getStatistics(tunnel)
                    if (st != null) {
                        val rx = st.totalRx()
                        val tx = st.totalTx()
                        _stats.value = Stats(
                            rx, tx,
                            if (lastRx < 0) 0 else (rx - lastRx).coerceAtLeast(0),
                            if (lastTx < 0) 0 else (tx - lastTx).coerceAtLeast(0),
                            (System.currentTimeMillis() - start) / 1000
                        )
                        lastRx = rx; lastTx = tx
                    }
                } catch (_: Exception) {}
                delay(1000)
            }
        }
    }

    /** Throws if the text is not a valid WireGuard config. */
    fun validate(conf: String) { Config.parse(ByteArrayInputStream(conf.toByteArray())) }

    /** Split tunneling: returns the config with an ExcludedApplications line for the given packages. */
    fun withExcluded(conf: String, packages: Set<String>): String {
        if (packages.isEmpty()) return conf
        val lines = conf.lines().filterNot { l ->
            val key = l.trim().lowercase().substringBefore('=').trim()
            key == "excludedapplications" || key == "includedapplications"
        }.toMutableList()
        val idx = lines.indexOfFirst { it.trim().equals("[Interface]", ignoreCase = true) }
        if (idx < 0) return conf
        lines.add(idx + 1, "ExcludedApplications = " + packages.sorted().joinToString(", "))
        return lines.joinToString("\n")
    }

    /** VPN permission must already be granted (VpnService.prepare). */
    fun connect(context: Context, conf: String) {
        val app = context.applicationContext
        setState(VpnState.CONNECTING)
        _error.value = null
        scope.launch {
            try {
                val config = Config.parse(ByteArrayInputStream(conf.toByteArray()))
                val b = backend ?: GoBackend(app).also { backend = it }
                b.setState(tunnel, Tunnel.State.UP, config)
                setState(VpnState.CONNECTED)
            } catch (e: Exception) {
                setState(VpnState.DISCONNECTED)
                _error.value = e.message ?: e.javaClass.simpleName
            }
        }
    }

    /** Re-reads the real tunnel state (e.g. after the activity was recreated). */
    fun refresh(context: Context) {
        val app = context.applicationContext
        scope.launch {
            try {
                val b = backend ?: GoBackend(app).also { backend = it }
                setState(if (b.getState(tunnel) == Tunnel.State.UP) VpnState.CONNECTED else VpnState.DISCONNECTED)
            } catch (_: Exception) {}
        }
    }

    fun disconnect() {
        scope.launch {
            try { backend?.setState(tunnel, Tunnel.State.DOWN, null) } catch (_: Exception) {}
            setState(VpnState.DISCONNECTED)
        }
    }
}
