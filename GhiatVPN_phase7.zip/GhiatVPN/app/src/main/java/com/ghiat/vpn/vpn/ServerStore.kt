package com.ghiat.vpn.vpn

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

data class Server(val id: String, val name: String, val flag: String, val conf: String)

/** Saves servers (name + WireGuard config) encrypted with a key held in the Android Keystore. */
class ServerStore(context: Context) {
    private val prefs = context.getSharedPreferences("servers", Context.MODE_PRIVATE)

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        gen.init(
            KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return gen.generateKey()
    }

    private fun encrypt(plain: String): String {
        val c = Cipher.getInstance("AES/GCM/NoPadding").apply { init(Cipher.ENCRYPT_MODE, key()) }
        val out = c.iv + c.doFinal(plain.toByteArray())
        return Base64.encodeToString(out, Base64.NO_WRAP)
    }

    private fun decrypt(data: String): String {
        val raw = Base64.decode(data, Base64.NO_WRAP)
        val c = Cipher.getInstance("AES/GCM/NoPadding")
            .apply { init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, raw.copyOfRange(0, 12))) }
        return String(c.doFinal(raw, 12, raw.size - 12))
    }

    fun load(): List<Server> {
        val json = try {
            prefs.getString("enc", null)?.let { decrypt(it) }
                ?: prefs.getString("list", null)  // legacy plaintext (phase 4 and older)
                ?: "[]"
        } catch (e: Exception) { "[]" }
        val arr = JSONArray(json)
        val list = (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Server(o.getString("id"), o.getString("name"), o.optString("flag", "🌐"), o.getString("conf"))
        }
        if (prefs.contains("list")) save(list)  // migrate legacy data, then wipe the plaintext copy
        return list
    }

    fun save(list: List<Server>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("id", it.id).put("name", it.name).put("flag", it.flag).put("conf", it.conf))
        }
        prefs.edit().putString("enc", encrypt(arr.toString())).remove("list").apply()
    }

    private companion object { const val ALIAS = "ghiatvpn_servers_key" }
}
