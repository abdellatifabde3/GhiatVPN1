# GhiatVPN - Phase 6
1. Install Android Studio (latest), then File > Open > select the GhiatVPN folder.
2. Wait for Gradle sync (needs internet the first time).
3. Plug in your phone (USB debugging on) and press Run, or Build > Build APK(s).
4. For Play Store: see store/PLAY_STORE_GUIDE.md.

Phase 5: Keystore-encrypted configs, no cloud backup, .conf import / clipboard paste, state re-sync.
Phase 6: QR scan (Google code scanner), kill switch shortcut (system Always-on + Block connections),
split tunneling (apps that bypass the VPN), live speed / traffic / duration stats.
