package com.ghiat.vpn.security

import android.content.Context
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity

/** Fingerprint / face with screen-lock (PIN, pattern, password) as fallback. */
object Auth {
    private val ALLOWED = BiometricManager.Authenticators.BIOMETRIC_WEAK or
        BiometricManager.Authenticators.DEVICE_CREDENTIAL

    /** True while the system prompt is on screen (the app going "background" then is not leaving). */
    @Volatile var busy = false
        private set

    fun available(ctx: Context): Boolean =
        BiometricManager.from(ctx).canAuthenticate(ALLOWED) == BiometricManager.BIOMETRIC_SUCCESS

    fun prompt(activity: FragmentActivity, title: String, onOk: () -> Unit, onFail: () -> Unit = {}) {
        if (busy) return
        busy = true
        val prompt = BiometricPrompt(activity, ContextCompat.getMainExecutor(activity),
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    busy = false; onOk()
                }
                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    busy = false; onFail()
                }
            })
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle(title)
            .setAllowedAuthenticators(ALLOWED)
            .build()
        prompt.authenticate(info)
    }
}
