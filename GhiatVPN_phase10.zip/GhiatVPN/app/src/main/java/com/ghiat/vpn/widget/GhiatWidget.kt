package com.ghiat.vpn.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.widget.RemoteViews
import android.widget.Toast
import com.ghiat.vpn.MainActivity
import com.ghiat.vpn.R
import com.ghiat.vpn.vpn.ConnectionManager
import com.ghiat.vpn.vpn.ToggleResult
import com.ghiat.vpn.vpn.VpnController
import com.ghiat.vpn.vpn.VpnState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/** Home screen widget: the power button toggles the VPN, the text opens the app. */
class GhiatWidget : AppWidgetProvider() {

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        appWidgetIds.forEach { appWidgetManager.updateAppWidget(it, build(context)) }
    }

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == ACTION_TOGGLE) {
            val app = context.applicationContext
            val pending = goAsync()
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    if (ConnectionManager.toggle(app) == ToggleResult.NEEDS_APP) {
                        Handler(Looper.getMainLooper()).post {
                            Toast.makeText(app, R.string.widget_open_app, Toast.LENGTH_LONG).show()
                        }
                    }
                } catch (_: Exception) {} finally { pending.finish() }
            }
        } else super.onReceive(context, intent)
    }

    companion object {
        const val ACTION_TOGGLE = "com.ghiat.vpn.WIDGET_TOGGLE"
        private const val GREEN = 0xFF2E7D32.toInt()
        private const val BLUE = 0xFF1565C0.toInt()
        private const val BLUE_LIGHT = 0xFF42A5F5.toInt()

        fun updateAll(ctx: Context) {
            try {
                val mgr = AppWidgetManager.getInstance(ctx)
                val ids = mgr.getAppWidgetIds(ComponentName(ctx, GhiatWidget::class.java))
                ids.forEach { mgr.updateAppWidget(it, build(ctx)) }
            } catch (_: Exception) {}
        }

        private fun build(ctx: Context): RemoteViews {
            val v = RemoteViews(ctx.packageName, R.layout.widget_ghiat)
            val state = VpnController.state.value
            val name = VpnController.activeName.value
            val (color, bg) = when (state) {
                VpnState.CONNECTED -> GREEN to R.drawable.widget_bg_on
                VpnState.CONNECTING -> BLUE_LIGHT to R.drawable.widget_bg
                VpnState.DISCONNECTED -> BLUE to R.drawable.widget_bg
            }
            val status = when (state) {
                VpnState.CONNECTED -> ctx.getString(R.string.connected) + (name?.let { " • $it" } ?: "")
                VpnState.CONNECTING -> ctx.getString(R.string.connecting)
                VpnState.DISCONNECTED -> ctx.getString(R.string.tap_connect)
            }
            v.setTextViewText(R.id.w_title, ctx.getString(R.string.app_name))
            v.setTextViewText(R.id.w_status, status)
            v.setInt(R.id.w_power, "setColorFilter", color)
            v.setInt(R.id.w_root, "setBackgroundResource", bg)
            val toggle = PendingIntent.getBroadcast(
                ctx, 0, Intent(ctx, GhiatWidget::class.java).setAction(ACTION_TOGGLE),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val open = PendingIntent.getActivity(
                ctx, 1, Intent(ctx, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            v.setOnClickPendingIntent(R.id.w_power, toggle)
            v.setOnClickPendingIntent(R.id.w_info, open)
            return v
        }
    }
}
