package com.ghiat.vpn.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ghiat.vpn.R
import com.ghiat.vpn.vpn.AppSettings
import com.ghiat.vpn.vpn.ConfigBuilder
import com.ghiat.vpn.vpn.PrivacyChecker
import com.ghiat.vpn.vpn.Profile
import com.ghiat.vpn.vpn.ServerStore
import com.ghiat.vpn.vpn.SplitMode
import com.ghiat.vpn.vpn.TraceResult
import com.ghiat.vpn.vpn.VpnController
import com.ghiat.vpn.vpn.VpnState
import kotlinx.coroutines.launch

private data class Check(val ok: Boolean, val text: Int)

private fun evaluate(p: Profile): List<Check> {
    val conf = ConfigBuilder.build(p)
    val allowed = ConfigBuilder.allowedIps(conf)
    val v4 = "0.0.0.0/0" in allowed || ("0.0.0.0/1" in allowed && "128.0.0.0/1" in allowed)
    val v6 = "::/0" in allowed || ("::/1" in allowed && "8000::/1" in allowed)
    val dns = ConfigBuilder.hasDns(conf)
    val noSplit = p.splitMode == SplitMode.OFF
    return listOf(
        Check(v4, if (v4) R.string.chk_ipv4 else R.string.chk_ipv4_bad),
        Check(v6, if (v6) R.string.chk_ipv6 else R.string.chk_ipv6_bad),
        Check(dns, if (dns) R.string.chk_dns else R.string.chk_dns_bad),
        Check(noSplit, if (noSplit) R.string.chk_split else R.string.chk_split_bad)
    )
}

@Composable
fun PrivacyScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    BackHandler(onBack = onBack)
    val profile = remember {
        val list = ServerStore(context).load()
        val id = AppSettings(context).selectedId
        list.firstOrNull { it.id == id } ?: list.firstOrNull()
    }
    val checks = remember(profile) { profile?.let { evaluate(it) } }
    val vpnState by VpnController.state.collectAsState()
    var result by remember { mutableStateOf<TraceResult?>(null) }
    var loading by remember { mutableStateOf(false) }
    var failed by remember { mutableStateOf(false) }
    var wasConnected by remember { mutableStateOf(false) }

    fun run() {
        loading = true; failed = false
        scope.launch {
            val connected = VpnController.state.value == VpnState.CONNECTED
            val r = PrivacyChecker.trace()
            loading = false
            if (r == null) failed = true
            else {
                if (!connected) PrivacyChecker.direct = r
                wasConnected = connected
                result = r
            }
        }
    }

    LazyColumn(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)
            .statusBarsPadding().navigationBarsPadding().padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = onBack) { Text("←", fontSize = 22.sp) }
                Text(stringResource(R.string.privacy_title), fontSize = 22.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            }
        }
        item {
            SectionCard {
                Text(stringResource(R.string.privacy_checks), fontWeight = FontWeight.Bold)
                if (profile != null) Text(profile.flag + " " + profile.name, fontSize = 12.sp, color = Color.Gray)
                if (checks == null) Text(stringResource(R.string.no_profile), fontSize = 13.sp, color = Color.Gray)
                else checks.forEach { c ->
                    Row(verticalAlignment = Alignment.Top) {
                        Text(if (c.ok) "✓" else "⚠", color = if (c.ok) Color(0xFF2E7D32) else Color(0xFFEF6C00), fontWeight = FontWeight.Bold)
                        Spacer(Modifier.width(8.dp))
                        Text(stringResource(c.text), fontSize = 14.sp)
                    }
                }
            }
        }
        item {
            SectionCard {
                Text(stringResource(R.string.online_title), fontWeight = FontWeight.Bold)
                Text(stringResource(R.string.online_desc), fontSize = 12.sp, color = Color.Gray)
                Button(onClick = { run() }, enabled = !loading) {
                    Text(stringResource(if (loading) R.string.checking else R.string.check_now))
                }
                if (failed) Text(stringResource(R.string.check_failed), color = Color(0xFFC62828), fontSize = 13.sp)
                result?.let { r ->
                    Text(stringResource(R.string.your_ip) + ": " + r.ip, fontWeight = FontWeight.SemiBold)
                    r.country?.let { Text(stringResource(R.string.your_country) + ": " + it) }
                    val direct = PrivacyChecker.direct
                    val verdict = when {
                        !wasConnected -> R.string.baseline_saved
                        direct == null -> R.string.verdict_need_baseline
                        direct.ip == r.ip -> R.string.verdict_leak
                        else -> R.string.verdict_ok
                    }
                    val bad = wasConnected && direct != null && direct.ip == r.ip
                    Text(stringResource(verdict), fontSize = 13.sp, color = if (bad) Color(0xFFC62828) else Color(0xFF2E7D32))
                    if (wasConnected && profile?.splitMode == SplitMode.ONLY) {
                        Text(stringResource(R.string.only_mode_note), fontSize = 12.sp, color = Color.Gray)
                    }
                }
                if (vpnState == VpnState.CONNECTING) Text(stringResource(R.string.connecting), fontSize = 12.sp, color = Color.Gray)
            }
        }
        item { Spacer(Modifier.height(16.dp)) }
    }
}
