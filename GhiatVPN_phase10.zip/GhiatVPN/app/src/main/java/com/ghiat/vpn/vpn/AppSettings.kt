package com.ghiat.vpn.vpn

import android.content.Context

enum class AutoMode { OFF, WIFI, ANY }

enum class ThemeMode { SYSTEM, LIGHT, DARK }

/** Non-sensitive user settings and connection intent flags. */
class AppSettings(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("settings", Context.MODE_PRIVATE)

    private fun getB(k: String, d: Boolean = false) = prefs.getBoolean(k, d)
    private fun putB(k: String, v: Boolean) = prefs.edit().putBoolean(k, v).apply()

    /** Old global "apps that bypass" list (phase 6); migrated into profiles by ServerStore. */
    var legacyExcluded: Set<String>
        get() = prefs.getStringSet("excluded", emptySet())?.toSet() ?: emptySet()
        set(v) { prefs.edit().putStringSet("excluded", v.toSet()).apply() }

    var selectedId: String?
        get() = prefs.getString("selectedId", null)
        set(v) { prefs.edit().putString("selectedId", v).apply() }

    /** True = pick the lowest-ping server at connect time. */
    var autoPick: Boolean
        get() = getB("autoPick"); set(v) = putB("autoPick", v)

    var autoMode: AutoMode
        get() = runCatching { AutoMode.valueOf(prefs.getString("autoMode", "OFF") ?: "OFF") }.getOrDefault(AutoMode.OFF)
        set(v) { prefs.edit().putString("autoMode", v.name).apply() }

    /** Restore the VPN after reboot / failed attempt if the user did not turn it off. */
    var reconnect: Boolean
        get() = getB("reconnect"); set(v) = putB("reconnect", v)

    /** The user (or a successful connect) wants the VPN up. Cleared on manual or system disconnect. */
    var wantConnected: Boolean
        get() = getB("wantConnected"); set(v) = putB("wantConnected", v)

    /** User disconnected by hand: auto-connect stays quiet until the matching network changes. */
    var manualOff: Boolean
        get() = getB("manualOff"); set(v) = putB("manualOff", v)

    var appLock: Boolean
        get() = getB("appLock"); set(v) = putB("appLock", v)

    var lockTimeoutSec: Int
        get() = prefs.getInt("lockTimeout", 30)
        set(v) { prefs.edit().putInt("lockTimeout", v).apply() }

    /** Wall-clock time the app last went to the background (for app-lock timing). */
    var lastLeftAt: Long
        get() = prefs.getLong("lastLeftAt", 0L)
        set(v) { prefs.edit().putLong("lastLeftAt", v).apply() }

    var secureWindow: Boolean
        get() = getB("secureWindow"); set(v) = putB("secureWindow", v)

    var themeMode: ThemeMode
        get() = runCatching { ThemeMode.valueOf(prefs.getString("theme", "SYSTEM") ?: "SYSTEM") }.getOrDefault(ThemeMode.SYSTEM)
        set(v) { prefs.edit().putString("theme", v.name).apply() }

    /** Ongoing status notification while connected (needs the notification permission on Android 13+). */
    var notify: Boolean
        get() = getB("notify"); set(v) = putB("notify", v)

    /** Off by default: no history is stored unless the user turns it on. */
    var keepHistory: Boolean
        get() = getB("keepHistory"); set(v) = putB("keepHistory", v)
}
