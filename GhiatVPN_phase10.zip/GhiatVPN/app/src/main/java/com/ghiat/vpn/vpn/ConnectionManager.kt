package com.ghiat.vpn.vpn

import android.content.Context
import android.net.VpnService
import com.ghiat.vpn.R
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

enum class ToggleResult { STARTED, STOPPED, NEEDS_APP, BUSY }

/** One place that decides which server to use and starts/stops the tunnel (UI, tile, widget, auto-connect). */
object ConnectionManager {
    private val mutex = Mutex()

    /** Connects using the saved selection (a specific server, or the fastest one in Auto mode). */
    suspend fun connectSelected(ctx: Context): Boolean = mutex.withLock {
        val app = ctx.applicationContext
        if (VpnController.state.value != VpnState.DISCONNECTED) return@withLock false
        val settings = AppSettings(app)
        val profiles = withContext(Dispatchers.IO) { ServerStore(app).load() }
        if (profiles.isEmpty()) {
            VpnController.fail(app.getString(R.string.err_no_servers))
            return@withLock false
        }
        VpnController.beginConnecting()
        val profile = pick(settings, profiles)
        settings.wantConnected = true
        settings.manualOff = false
        // Drop apps that were uninstalled since the profile was saved.
        val installed = withContext(Dispatchers.IO) { Apps.launcherPackages(app) }
        val ready = profile.copy(apps = profile.apps.filter { it in installed }.toSet())
        VpnController.connectNow(app, ConfigBuilder.build(ready), profile.name)
        VpnController.state.value == VpnState.CONNECTED
    }

    private suspend fun pick(s: AppSettings, profiles: List<Profile>): Profile {
        val chosen = profiles.firstOrNull { it.id == s.selectedId } ?: profiles.first()
        if (!s.autoPick || profiles.size == 1) return chosen
        val best = LatencyTester.testAll(profiles).filterValues { it != null }
            .minByOrNull { it.value!! }?.key
        return profiles.firstOrNull { it.id == best } ?: chosen
    }

    fun disconnectByUser(ctx: Context) {
        AppSettings(ctx).apply { wantConnected = false; manualOff = true }
        VpnController.disconnect()
    }

    /** Used by the quick tile and the widget. */
    suspend fun toggle(ctx: Context): ToggleResult {
        val app = ctx.applicationContext
        return when (VpnController.state.value) {
            VpnState.CONNECTED -> { disconnectByUser(app); ToggleResult.STOPPED }
            VpnState.CONNECTING -> ToggleResult.BUSY
            VpnState.DISCONNECTED -> {
                val none = withContext(Dispatchers.IO) { ServerStore(app).load().isEmpty() }
                if (none || VpnService.prepare(app) != null) ToggleResult.NEEDS_APP
                else { connectSelected(app); ToggleResult.STARTED }
            }
        }
    }
}
