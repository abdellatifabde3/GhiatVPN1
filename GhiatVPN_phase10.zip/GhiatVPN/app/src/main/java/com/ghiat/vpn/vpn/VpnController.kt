package com.ghiat.vpn.vpn

import android.app.Application
import android.content.ComponentName
import android.content.Context
import android.service.quicksettings.TileService
import com.ghiat.vpn.notify.Notifier
import com.ghiat.vpn.tile.VpnTileService
import com.ghiat.vpn.widget.GhiatWidget
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.Config
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayInputStream

enum class VpnState { DISCONNECTED, CONNECTING, CONNECTED }

/** Live traffic numbers: totals in bytes, speeds in bytes/second, duration in seconds. */
data class Stats(val rx: Long = 0, val tx: Long = 0, val rxSpeed: Long = 0, val txSpeed: Long = 0, val seconds: Long = 0)

/** Real WireGuard tunnel through the official wireguard-android library. */
object VpnController {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var backend: GoBackend? = null
    private var statsJob: Job? = null
    private var appCtx: Context? = null
    @Volatile private var userDown = false

    private val _state = MutableStateFlow(VpnState.DISCONNECTED)
    val state: StateFlow<VpnState> = _state
    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error
    private val _stats = MutableStateFlow(Stats())
    val stats: StateFlow<Stats> = _stats
    private val _activeName = MutableStateFlow<String?>(null)
    val activeName: StateFlow<String?> = _activeName

    private val tunnel = object : Tunnel {
        override fun getName() = "ghiatvpn"
        override fun onStateChange(newState: Tunnel.State) {
            if (newState == Tunnel.State.UP) {
                setState(VpnState.CONNECTED)
            } else {
                // Down without the user asking (revoked by another VPN, system disconnect):
                // do not fight it by auto-reconnecting later.
                if (!userDown) appCtx?.let { AppSettings(it).wantConnected = false }
                userDown = false
                _activeName.value = null
                setState(VpnState.DISCONNECTED)
            }
        }
    }

    /** Called once from Application.onCreate: keeps the widget and quick tile in sync with the state. */
    fun attach(app: Application) {
        appCtx = app
        scope.launch {
            combine(_state, _activeName) { s, n -> s to n }.collect {
                GhiatWidget.updateAll(app)
                Notifier.update(app, it.first, it.second)
                try {
                    TileService.requestListeningState(app, ComponentName(app, VpnTileService::class.java))
                } catch (_: Exception) {}
            }
        }
    }

    private var sessionStart = 0L
    private var sessionName: String? = null

    private fun recordSession() {
        val ctx = appCtx ?: return
        if (sessionStart == 0L || !AppSettings(ctx).keepHistory) { sessionStart = 0L; return }
        val st = _stats.value
        HistoryStore(ctx).add(HistoryEntry(sessionStart, sessionName ?: "", (System.currentTimeMillis() - sessionStart) / 1000, st.rx, st.tx))
        sessionStart = 0L
    }

    private fun setState(s: VpnState) {
        val prev = _state.value
        if (prev != VpnState.CONNECTED && s == VpnState.CONNECTED) { sessionStart = System.currentTimeMillis(); sessionName = _activeName.value }
        if (prev == VpnState.CONNECTED && s != VpnState.CONNECTED) recordSession()
        _state.value = s
        if (s == VpnState.CONNECTED) {
            if (statsJob?.isActive != true) startStats()
        } else {
            statsJob?.cancel(); statsJob = null
            _stats.value = Stats()
        }
    }

    private fun startStats() {
        statsJob = scope.launch {
            val start = System.currentTimeMillis()
            var lastRx = -1L
            var lastTx = -1L
            while (isActive) {
                try {
                    val st = backend?.getStatistics(tunnel)
                    if (st != null) {
                        val rx = st.totalRx()
                        val tx = st.totalTx()
                        _stats.value = Stats(
                            rx, tx,
                            if (lastRx < 0) 0 else (rx - lastRx).coerceAtLeast(0),
                            if (lastTx < 0) 0 else (tx - lastTx).coerceAtLeast(0),
                            (System.currentTimeMillis() - start) / 1000
                        )
                        lastRx = rx; lastTx = tx
                    }
                } catch (_: Exception) {}
                delay(1000)
            }
        }
    }

    /** Throws if the text is not a valid WireGuard config. */
    fun validate(conf: String) { Config.parse(ByteArrayInputStream(conf.toByteArray())) }

    fun beginConnecting() { _error.value = null; setState(VpnState.CONNECTING) }

    fun fail(message: String) { _error.value = message; setState(VpnState.DISCONNECTED) }

    /** VPN permission must already be granted (VpnService.prepare). Safe to call from any thread. */
    suspend fun connectNow(context: Context, conf: String, name: String) = withContext(Dispatchers.IO) {
        val app = context.applicationContext
        appCtx = app
        setState(VpnState.CONNECTING)
        _error.value = null
        try {
            val config = Config.parse(ByteArrayInputStream(conf.toByteArray()))
            val b = backend ?: GoBackend(app).also { backend = it }
            _activeName.value = name
            b.setState(tunnel, Tunnel.State.UP, config)
            setState(VpnState.CONNECTED)
        } catch (e: Exception) {
            _activeName.value = null
            setState(VpnState.DISCONNECTED)
            _error.value = e.message ?: e.javaClass.simpleName
        }
        Unit
    }

    /** Re-reads the real tunnel state (e.g. after the activity was recreated). */
    fun refresh(context: Context) {
        val app = context.applicationContext
        scope.launch {
            try {
                if (_state.value == VpnState.CONNECTING) return@launch
                val b = backend ?: GoBackend(app).also { backend = it }
                setState(if (b.getState(tunnel) == Tunnel.State.UP) VpnState.CONNECTED else VpnState.DISCONNECTED)
            } catch (_: Exception) {}
        }
    }

    fun disconnect() {
        userDown = true
        scope.launch {
            try { backend?.setState(tunnel, Tunnel.State.DOWN, null) } catch (_: Exception) {}
            _activeName.value = null
            setState(VpnState.DISCONNECTED)
        }
    }
}
