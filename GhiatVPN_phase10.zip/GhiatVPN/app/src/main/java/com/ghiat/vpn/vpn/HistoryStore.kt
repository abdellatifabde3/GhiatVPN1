package com.ghiat.vpn.vpn

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class HistoryEntry(val start: Long, val name: String, val seconds: Long, val rx: Long, val tx: Long)

/** Optional local log of sessions: time, server name, duration, data. No IPs, never leaves the device. */
class HistoryStore(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("history", Context.MODE_PRIVATE)

    /** Newest first. */
    fun load(): List<HistoryEntry> = try {
        val arr = JSONArray(prefs.getString("items", "[]"))
        (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            HistoryEntry(o.getLong("s"), o.optString("n"), o.getLong("d"), o.getLong("r"), o.getLong("t"))
        }
    } catch (_: Exception) { emptyList() }

    fun add(e: HistoryEntry) {
        val list = (listOf(e) + load()).take(MAX)
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("s", it.start).put("n", it.name).put("d", it.seconds).put("r", it.rx).put("t", it.tx)) }
        prefs.edit().putString("items", arr.toString()).apply()
    }

    fun clear() { prefs.edit().remove("items").apply() }

    private companion object { const val MAX = 100 }
}
