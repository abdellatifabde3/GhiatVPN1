package com.ghiat.vpn.tile

import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import com.ghiat.vpn.MainActivity
import com.ghiat.vpn.R
import com.ghiat.vpn.vpn.ConnectionManager
import com.ghiat.vpn.vpn.ToggleResult
import com.ghiat.vpn.vpn.VpnController
import com.ghiat.vpn.vpn.VpnState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Quick Settings tile that toggles the VPN. */
class VpnTileService : TileService() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var job: Job? = null

    override fun onStartListening() {
        render()
        job = scope.launch {
            combine(VpnController.state, VpnController.activeName) { s, n -> s to n }.collect { render() }
        }
    }

    override fun onStopListening() { job?.cancel(); job = null }

    override fun onDestroy() { scope.cancel(); super.onDestroy() }

    override fun onClick() {
        scope.launch {
            val r = withContext(Dispatchers.IO) { ConnectionManager.toggle(applicationContext) }
            if (r == ToggleResult.NEEDS_APP) openApp()
        }
    }

    private fun render() {
        val t = qsTile ?: return
        val state = VpnController.state.value
        t.state = if (state == VpnState.CONNECTED) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        t.label = getString(R.string.app_name)
        if (Build.VERSION.SDK_INT >= 29) {
            t.subtitle = when (state) {
                VpnState.CONNECTED -> VpnController.activeName.value ?: getString(R.string.connected)
                VpnState.CONNECTING -> getString(R.string.connecting)
                VpnState.DISCONNECTED -> getString(R.string.status_off)
            }
        }
        t.updateTile()
    }

    @Suppress("DEPRECATION")
    private fun openApp() {
        val i = Intent(this, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            .putExtra(MainActivity.EXTRA_CONNECT, true)
        if (Build.VERSION.SDK_INT >= 34) {
            startActivityAndCollapse(
                PendingIntent.getActivity(this, 2, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            )
        } else startActivityAndCollapse(i)
    }
}
