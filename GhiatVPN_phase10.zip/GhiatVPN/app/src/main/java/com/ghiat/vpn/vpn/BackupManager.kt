package com.ghiat.vpn.vpn

import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/**
 * Password-protected backup of all servers. Format: "GVPN1" + salt(16) + iv(12) + AES-256-GCM ciphertext,
 * key = PBKDF2-HMAC-SHA256(password, salt, 210000 rounds). A wrong password or edited file fails to decrypt.
 */
object BackupManager {
    private val MAGIC = "GVPN1".toByteArray()
    private const val ITERATIONS = 210_000
    private const val SALT = 16
    private const val IV = 12

    private fun key(password: String, salt: ByteArray): SecretKeySpec {
        val spec = PBEKeySpec(password.toCharArray(), salt, ITERATIONS, 256)
        val bytes = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        spec.clearPassword()
        return SecretKeySpec(bytes, "AES")
    }

    fun export(list: List<Profile>, password: String): ByteArray {
        val rnd = SecureRandom()
        val salt = ByteArray(SALT).also { rnd.nextBytes(it) }
        val iv = ByteArray(IV).also { rnd.nextBytes(it) }
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, key(password, salt), GCMParameterSpec(128, iv))
        c.updateAAD(MAGIC)
        return MAGIC + salt + iv + c.doFinal(ServerStore.encode(list).toByteArray(Charsets.UTF_8))
    }

    /** Throws on a wrong password, a damaged file or a file that is not a GhiatVPN backup. */
    fun import(data: ByteArray, password: String): List<Profile> {
        val head = MAGIC.size + SALT + IV
        require(data.size > head + 16 && data.copyOfRange(0, MAGIC.size).contentEquals(MAGIC)) { "not a backup" }
        val salt = data.copyOfRange(MAGIC.size, MAGIC.size + SALT)
        val iv = data.copyOfRange(MAGIC.size + SALT, head)
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.DECRYPT_MODE, key(password, salt), GCMParameterSpec(128, iv))
        c.updateAAD(MAGIC)
        return ServerStore.decode(String(c.doFinal(data, head, data.size - head), Charsets.UTF_8))
    }
}
