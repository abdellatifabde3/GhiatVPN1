package com.ghiat.vpn.vpn

import android.content.Context
import android.content.Intent

data class AppEntry(val label: String, val pkg: String)

object Apps {
    /** Launchable apps (needs the <queries> launcher intent in the manifest). */
    fun launcherApps(context: Context): List<AppEntry> {
        val pm = context.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(intent, 0)
            .map { AppEntry(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
            .filter { it.pkg != context.packageName }
            .distinctBy { it.pkg }
            .sortedBy { it.label.lowercase() }
    }

    fun launcherPackages(context: Context): Set<String> = launcherApps(context).map { it.pkg }.toSet()
}
