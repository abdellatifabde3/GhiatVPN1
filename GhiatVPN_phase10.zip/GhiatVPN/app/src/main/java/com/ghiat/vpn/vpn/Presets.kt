package com.ghiat.vpn.vpn

import androidx.annotation.StringRes
import com.ghiat.vpn.R

/** Quick templates for the profile editor. [split] == null leaves the split settings unchanged. */
data class Preset(
    @StringRes val label: Int,
    val dns: DnsOption?,
    val split: SplitMode?,
    val packages: List<String> = emptyList()
)

object Presets {
    private val browsers = listOf(
        "com.android.chrome", "org.mozilla.firefox", "org.mozilla.firefox_beta", "org.mozilla.fenix",
        "com.brave.browser", "com.microsoft.emmx", "com.opera.browser", "com.opera.mini.native",
        "com.duckduckgo.mobile.android", "com.sec.android.app.sbrowser", "com.kiwibrowser.browser",
        "com.vivaldi.browser"
    )
    private val messaging = listOf(
        "com.whatsapp", "com.whatsapp.w4b", "org.telegram.messenger", "org.thoughtcrime.securesms",
        "com.facebook.orca", "com.discord", "com.viber.voip"
    )
    private val streaming = listOf(
        "com.google.android.youtube", "com.google.android.apps.youtube.music", "com.netflix.mediaclient",
        "com.spotify.music", "com.disney.disneyplus", "com.amazon.avod.thirdpartyclient", "tv.twitch.android.app"
    )

    val all = listOf(
        Preset(R.string.preset_full, null, SplitMode.OFF),
        Preset(R.string.preset_browsers, null, SplitMode.ONLY, browsers),
        Preset(R.string.preset_messaging, null, SplitMode.ONLY, messaging),
        Preset(R.string.preset_streaming, null, SplitMode.BYPASS, streaming),
        Preset(R.string.preset_adblock, DnsOption.ADGUARD, null)
    )
}
