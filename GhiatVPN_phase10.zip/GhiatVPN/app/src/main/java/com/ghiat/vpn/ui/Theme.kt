package com.ghiat.vpn.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import com.ghiat.vpn.vpn.ThemeMode

val Blue = Color(0xFF1565C0)
val BlueLight = Color(0xFF42A5F5)
val Bg = Color(0xFFF4F8FF)

private val DarkBg = Color(0xFF0E1621)
private val DarkSurface = Color(0xFF1A2433)

fun isDark(mode: ThemeMode, systemDark: Boolean) = mode == ThemeMode.DARK || (mode == ThemeMode.SYSTEM && systemDark)

@Composable
fun GhiatTheme(mode: ThemeMode = ThemeMode.SYSTEM, content: @Composable () -> Unit) {
    val dark = isDark(mode, isSystemInDarkTheme())
    val scheme = if (dark) darkColorScheme(
        primary = Color(0xFF64B5F6), secondary = BlueLight, background = DarkBg, surface = DarkSurface,
        onBackground = Color(0xFFE6EDF7), onSurface = Color(0xFFE6EDF7)
    ) else lightColorScheme(primary = Blue, secondary = BlueLight, background = Bg, surface = Color.White)
    MaterialTheme(colorScheme = scheme) {
        // Surface provides the default text colour (otherwise text stays black in dark mode).
        Surface(color = MaterialTheme.colorScheme.background, content = content)
    }
}
