package com.ghiat.vpn.auto

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.VpnService
import android.os.Build
import com.ghiat.vpn.vpn.AppSettings
import com.ghiat.vpn.vpn.AutoMode
import com.ghiat.vpn.vpn.ConnectionManager
import com.ghiat.vpn.vpn.VpnController
import com.ghiat.vpn.vpn.VpnState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

enum class NetType { NONE, WIFI, CELLULAR, OTHER }

/**
 * Auto-connect without location access: we cannot read the Wi-Fi name, so rules are by network TYPE.
 * The system delivers network events to a receiver through a PendingIntent, so it also works when
 * the app process is not running (no foreground service needed).
 */
object AutoConnect {
    private const val ACTION = "com.ghiat.vpn.NETWORK_EVENT"

    private fun pendingIntent(ctx: Context): PendingIntent {
        val i = Intent(ctx, NetworkEventReceiver::class.java).setAction(ACTION)
        val mutable = if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0
        return PendingIntent.getBroadcast(ctx, 0, i, PendingIntent.FLAG_UPDATE_CURRENT or mutable)
    }

    /**
     * Registers (or removes) the network listener to match the settings. The system replays the
     * current network right after registering, so call it only when settings change, after boot /
     * app update, and on a fresh app launch - not on every screen. manualOff guards the replay.
     */
    fun sync(ctx: Context) {
        val app = ctx.applicationContext
        val s = AppSettings(app)
        val cm = app.getSystemService(ConnectivityManager::class.java) ?: return
        val pi = pendingIntent(app)
        try { cm.unregisterNetworkCallback(pi) } catch (_: Exception) {}
        if (s.autoMode == AutoMode.OFF && !s.reconnect) return
        // VALIDATED = the system confirmed real internet, so captive portals do not trigger us.
        val req = NetworkRequest.Builder()
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .addCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
            .build()
        try { cm.registerNetworkCallback(req, pi) } catch (_: Exception) {}
    }

    /** Best non-VPN network that has working internet and is not behind a login page. */
    @Suppress("DEPRECATION")
    fun currentNetwork(ctx: Context): NetType {
        val cm = ctx.getSystemService(ConnectivityManager::class.java) ?: return NetType.NONE
        var best = NetType.NONE
        for (n in cm.allNetworks) {
            val c = cm.getNetworkCapabilities(n) ?: continue
            if (c.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) continue
            if (!c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) continue
            if (!c.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)) continue
            if (c.hasCapability(NetworkCapabilities.NET_CAPABILITY_CAPTIVE_PORTAL)) continue
            if (c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) return NetType.WIFI
            best = if (c.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) NetType.CELLULAR
            else if (best == NetType.NONE) NetType.OTHER else best
        }
        return best
    }

    /** Decides whether to connect now (rules are described in the README). */
    suspend fun evaluate(ctx: Context) {
        val app = ctx.applicationContext
        val s = AppSettings(app)
        val net = currentNetwork(app)
        val modeMatch = when (s.autoMode) {
            AutoMode.OFF -> false
            AutoMode.WIFI -> net == NetType.WIFI
            AutoMode.ANY -> net != NetType.NONE
        }
        // The matching network went away: the next one counts as new, so forget a manual disconnect.
        if (!modeMatch) s.manualOff = false
        if (net == NetType.NONE) return
        if (VpnController.state.value != VpnState.DISCONNECTED) return
        val restore = s.reconnect && s.wantConnected
        if (!(modeMatch && !s.manualOff) && !restore) return
        if (VpnService.prepare(app) != null) return  // permission not granted yet; needs the app
        ConnectionManager.connectSelected(app)
    }
}

class NetworkEventReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val app = context.applicationContext
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try { AutoConnect.evaluate(app) } catch (_: Exception) {} finally { pending.finish() }
        }
    }
}

/** Re-registers the network listener after a reboot or an app update (registrations do not survive reboot). */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED || intent.action == Intent.ACTION_MY_PACKAGE_REPLACED) {
            AutoConnect.sync(context)
        }
    }
}
