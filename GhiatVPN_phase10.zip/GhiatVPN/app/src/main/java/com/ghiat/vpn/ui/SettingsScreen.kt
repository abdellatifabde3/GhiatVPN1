package com.ghiat.vpn.ui

import android.Manifest
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Intent
import android.net.Uri
import android.net.VpnService
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.fragment.app.FragmentActivity
import com.ghiat.vpn.R
import com.ghiat.vpn.auto.AutoConnect
import com.ghiat.vpn.security.Auth
import com.ghiat.vpn.vpn.AppSettings
import com.ghiat.vpn.notify.Notifier
import com.ghiat.vpn.vpn.AutoMode
import com.ghiat.vpn.vpn.BackupManager
import com.ghiat.vpn.vpn.ServerStore
import com.ghiat.vpn.vpn.ThemeMode
import com.ghiat.vpn.vpn.VpnController
import com.ghiat.vpn.widget.GhiatWidget
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun SettingsScreen(
    onBack: () -> Unit,
    onOpenPrivacy: () -> Unit,
    onOpenHistory: () -> Unit,
    onThemeChanged: (ThemeMode) -> Unit,
    onSecureChanged: () -> Unit
) {
    val context = LocalContext.current
    BackHandler(onBack = onBack)
    val settings = remember { AppSettings(context) }
    var autoMode by remember { mutableStateOf(settings.autoMode) }
    var reconnect by remember { mutableStateOf(settings.reconnect) }
    var appLock by remember { mutableStateOf(settings.appLock) }
    var timeout by remember { mutableStateOf(settings.lockTimeoutSec) }
    var secure by remember { mutableStateOf(settings.secureWindow) }
    var msg by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    var backupUri by remember { mutableStateOf<Uri?>(null) }
    var backupExport by remember { mutableStateOf(true) }
    var pw by remember { mutableStateOf("") }
    var pw2 by remember { mutableStateOf("") }
    var info by remember { mutableStateOf<String?>(null) }
    val exportPicker = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
        if (uri != null) { backupExport = true; backupUri = uri; pw = ""; pw2 = "" }
    }
    val importPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) { backupExport = false; backupUri = uri; pw = ""; pw2 = "" }
    }
    var theme by remember { mutableStateOf(settings.themeMode) }
    var notify by remember { mutableStateOf(settings.notify && Notifier.granted(context)) }
    var keepHistory by remember { mutableStateOf(settings.keepHistory) }
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        notify = ok; settings.notify = ok
        if (!ok) msg = context.getString(R.string.notify_denied)
        Notifier.update(context, VpnController.state.value, VpnController.activeName.value)
    }

    fun applyAuto() {
        AutoConnect.sync(context)
        msg = if ((autoMode != AutoMode.OFF || reconnect) && VpnService.prepare(context) != null)
            context.getString(R.string.vpn_permission_first) else null
    }

    LazyColumn(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)
            .statusBarsPadding().navigationBarsPadding().padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = onBack) { Text("←", fontSize = 22.sp) }
                Text(stringResource(R.string.settings), fontSize = 22.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            }
        }
        item {
            SectionCard {
                Text(stringResource(R.string.theme_title), fontWeight = FontWeight.Bold)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(ThemeMode.SYSTEM to R.string.theme_system, ThemeMode.LIGHT to R.string.theme_light, ThemeMode.DARK to R.string.theme_dark)
                        .forEach { (m, label) ->
                            FilterChip(
                                selected = theme == m, modifier = Modifier.weight(1f),
                                onClick = { theme = m; settings.themeMode = m; onThemeChanged(m) },
                                label = { Text(stringResource(label), maxLines = 1) }
                            )
                        }
                }
            }
        }
        item {
            SectionCard {
                Text(stringResource(R.string.autoconnect_title), fontWeight = FontWeight.Bold)
                Text(stringResource(R.string.autoconnect_desc), fontSize = 12.sp, color = Color.Gray)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(AutoMode.OFF to R.string.auto_off, AutoMode.WIFI to R.string.auto_wifi, AutoMode.ANY to R.string.auto_any)
                        .forEach { (m, label) ->
                            FilterChip(
                                selected = autoMode == m, modifier = Modifier.weight(1f),
                                onClick = {
                                    autoMode = m; settings.autoMode = m
                                    if (m != AutoMode.OFF) settings.manualOff = false
                                    applyAuto()
                                },
                                label = { Text(stringResource(label), maxLines = 1) }
                            )
                        }
                }
                SwitchRow(stringResource(R.string.reconnect_title), stringResource(R.string.reconnect_desc), reconnect) {
                    reconnect = it; settings.reconnect = it; applyAuto()
                }
                msg?.let { Text(it, fontSize = 12.sp, color = Color(0xFFC62828)) }
            }
        }
        item {
            SectionCard {
                Text(stringResource(R.string.security_title), fontWeight = FontWeight.Bold)
                SwitchRow(stringResource(R.string.applock_title), stringResource(R.string.applock_desc), appLock) { on ->
                    if (!on) { appLock = false; settings.appLock = false }
                    else if (!Auth.available(context)) { msg = context.getString(R.string.no_screen_lock) }
                    else {
                        val act = context.findActivity() as? FragmentActivity
                        if (act != null) Auth.prompt(act, context.getString(R.string.unlock_title), onOk = {
                            appLock = true; settings.appLock = true; settings.lastLeftAt = System.currentTimeMillis()
                        })
                    }
                }
                if (appLock) {
                    Text(stringResource(R.string.lock_timeout_title), fontSize = 13.sp)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(0 to R.string.lock_now, 30 to R.string.lock_30s, 300 to R.string.lock_5m).forEach { (sec, label) ->
                            FilterChip(
                                selected = timeout == sec, modifier = Modifier.weight(1f),
                                onClick = { timeout = sec; settings.lockTimeoutSec = sec },
                                label = { Text(stringResource(label), maxLines = 1) }
                            )
                        }
                    }
                }
                SwitchRow(stringResource(R.string.secure_title), stringResource(R.string.secure_desc), secure) {
                    secure = it; settings.secureWindow = it; onSecureChanged()
                }
            }
        }
        item {
            SectionCard {
                SwitchRow(stringResource(R.string.notify_title), stringResource(R.string.notify_desc), notify) { on ->
                    if (!on) {
                        notify = false; settings.notify = false
                        Notifier.update(context, VpnController.state.value, VpnController.activeName.value)
                    } else if (Notifier.granted(context)) {
                        notify = true; settings.notify = true
                        Notifier.update(context, VpnController.state.value, VpnController.activeName.value)
                    } else if (Build.VERSION.SDK_INT >= 33) {
                        notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                    }
                }
                SwitchRow(stringResource(R.string.history_keep_title), stringResource(R.string.history_keep_desc), keepHistory) {
                    keepHistory = it; settings.keepHistory = it
                }
                TextButton(onClick = onOpenHistory) { Text(stringResource(R.string.history_open)) }
            }
        }
        item {
            SectionCard {
                Text(stringResource(R.string.privacy_title), fontWeight = FontWeight.Bold)
                TextButton(onClick = onOpenPrivacy) { Text(stringResource(R.string.privacy_check)) }
            }
        }
        item {
            SectionCard {
                Text(stringResource(R.string.shortcuts_title), fontWeight = FontWeight.Bold)
                Text(stringResource(R.string.shortcuts_desc), fontSize = 12.sp, color = Color.Gray)
                TextButton(onClick = {
                    val mgr = AppWidgetManager.getInstance(context)
                    if (mgr.isRequestPinAppWidgetSupported) {
                        mgr.requestPinAppWidget(ComponentName(context, GhiatWidget::class.java), null, null)
                    } else msg = context.getString(R.string.widget_unsupported)
                }) { Text(stringResource(R.string.add_widget)) }
            }
        }
        item {
            SectionCard {
                Text(stringResource(R.string.backup_title), fontWeight = FontWeight.Bold)
                Text(stringResource(R.string.backup_desc), fontSize = 12.sp, color = Color.Gray)
                Row {
                    TextButton(onClick = {
                        info = null
                        if (ServerStore(context).load().isEmpty()) msg = context.getString(R.string.backup_empty)
                        else exportPicker.launch("ghiatvpn-backup.gvpn")
                    }) { Text(stringResource(R.string.backup_export)) }
                    TextButton(onClick = { info = null; importPicker.launch(arrayOf("*/*")) }) {
                        Text(stringResource(R.string.backup_import))
                    }
                }
                info?.let { Text(it, fontSize = 13.sp, color = Color(0xFF2E7D32)) }
            }
        }
        item {
            SectionCard {
                Text(stringResource(R.string.kill_switch_title), fontWeight = FontWeight.Bold)
                Text(stringResource(R.string.kill_switch_desc), fontSize = 13.sp, color = Color.Gray)
                TextButton(onClick = {
                    try { context.startActivity(Intent(Settings.ACTION_VPN_SETTINGS)) } catch (_: Exception) {}
                }) { Text(stringResource(R.string.open_vpn_settings)) }
            }
        }
        item { Spacer(Modifier.height(16.dp)) }
    }

    backupUri?.let { uri ->
        AlertDialog(
            onDismissRequest = { backupUri = null },
            title = { Text(stringResource(if (backupExport) R.string.backup_export else R.string.backup_import)) },
            text = {
                Column {
                    OutlinedTextField(pw, { pw = it }, singleLine = true, visualTransformation = PasswordVisualTransformation(),
                        label = { Text(stringResource(R.string.backup_password)) })
                    if (backupExport) {
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(pw2, { pw2 = it }, singleLine = true, visualTransformation = PasswordVisualTransformation(),
                            label = { Text(stringResource(R.string.backup_repeat)) })
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (pw.length < 8) { msg = context.getString(R.string.backup_password_short); backupUri = null }
                    else if (backupExport && pw != pw2) { msg = context.getString(R.string.backup_mismatch); backupUri = null }
                    else {
                        val password = pw; val exporting = backupExport
                        backupUri = null; msg = null; info = null
                        scope.launch {
                            val result = withContext(Dispatchers.IO) {
                                runCatching {
                                    val store = ServerStore(context)
                                    if (exporting) {
                                        val bytes = BackupManager.export(store.load(), password)
                                        context.contentResolver.openOutputStream(uri)!!.use { it.write(bytes) }
                                        0
                                    } else {
                                        val data = context.contentResolver.openInputStream(uri)!!.use { it.readBytes() }
                                        val imported = BackupManager.import(data, password)
                                        val current = store.load()
                                        val known = current.map { it.id }.toSet()
                                        val added = imported.filter { it.id !in known }
                                        store.save(current + added)
                                        added.size
                                    }
                                }
                            }
                            result.onSuccess {
                                info = if (exporting) context.getString(R.string.backup_exported)
                                else context.getString(R.string.backup_imported, it)
                            }.onFailure {
                                msg = context.getString(if (exporting) R.string.invalid_config else R.string.backup_wrong)
                            }
                        }
                    }
                }) { Text(stringResource(R.string.continue_btn)) }
            },
            dismissButton = { TextButton(onClick = { backupUri = null }) { Text(stringResource(R.string.cancel)) } }
        )
    }
}
