package com.ghiat.vpn.vpn

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL

data class TraceResult(val ip: String, val country: String?)

/** Asks Cloudflare which IP/country the internet sees. Runs only when the user taps the button. */
object PrivacyChecker {
    /** IP seen while disconnected; kept in memory only, never written to disk. */
    @Volatile var direct: TraceResult? = null

    suspend fun trace(): TraceResult? = withContext(Dispatchers.IO) {
        try {
            val c = URL("https://www.cloudflare.com/cdn-cgi/trace").openConnection() as HttpURLConnection
            c.connectTimeout = 6000; c.readTimeout = 6000; c.useCaches = false
            try {
                val map = c.inputStream.bufferedReader().readLines().mapNotNull { l ->
                    l.split("=", limit = 2).takeIf { it.size == 2 }?.let { it[0] to it[1] }
                }.toMap()
                map["ip"]?.let { TraceResult(it, map["loc"]) }
            } finally { c.disconnect() }
        } catch (_: Exception) { null }
    }
}
