package com.ghiat.vpn

import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import androidx.activity.SystemBarStyle
import android.os.Bundle
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.Image
import androidx.fragment.app.FragmentActivity
import com.ghiat.vpn.auto.AutoConnect
import com.ghiat.vpn.security.Auth
import com.ghiat.vpn.ui.GhiatTheme
import com.ghiat.vpn.ui.HistoryScreen
import com.ghiat.vpn.ui.HomeScreen
import com.ghiat.vpn.ui.isDark
import com.ghiat.vpn.ui.PrivacyScreen
import com.ghiat.vpn.ui.ProfileEditorScreen
import com.ghiat.vpn.ui.SettingsScreen
import com.ghiat.vpn.vpn.AppSettings
import com.ghiat.vpn.vpn.ThemeMode

class MainActivity : FragmentActivity() {
    private lateinit var settings: AppSettings
    private var locked by mutableStateOf(false)
    private var connectRequest by mutableStateOf(false)
    private var themeMode by mutableStateOf(ThemeMode.SYSTEM)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        settings = AppSettings(this)
        themeMode = settings.themeMode
        applyBars()
        applySecureFlag()
        // Cold start always asks; a recreated activity (rotation, process restore) asks only after a long absence.
        locked = settings.appLock && (savedInstanceState == null || awayTooLong())
        if (intent?.getBooleanExtra(EXTRA_CONNECT, false) == true) connectRequest = true
        // Fresh launch only: re-register auto-connect once (a force-stop removes registrations).
        if (savedInstanceState == null) AutoConnect.sync(this)

        setContent {
            GhiatTheme(themeMode) {
                var screen by rememberSaveable { mutableStateOf("home") }
                var editId by rememberSaveable { mutableStateOf<String?>(null) }
                if (locked) {
                    LockScreen(onUnlock = { promptUnlock() })
                } else when (screen) {
                    "settings" -> SettingsScreen(
                        onBack = { screen = "home" },
                        onOpenPrivacy = { screen = "privacy" },
                        onOpenHistory = { screen = "history" },
                        onThemeChanged = { themeMode = it; applyBars() },
                        onSecureChanged = { applySecureFlag() }
                    )
                    "history" -> HistoryScreen(onBack = { screen = "settings" })
                    "privacy" -> PrivacyScreen(onBack = { screen = "home" })
                    "edit" -> ProfileEditorScreen(editId ?: "", onDone = { screen = "home" })
                    else -> HomeScreen(
                        autoConnect = connectRequest,
                        onAutoConnectHandled = { connectRequest = false },
                        onOpenSettings = { screen = "settings" },
                        onOpenPrivacy = { screen = "privacy" },
                        onEdit = { editId = it; screen = "edit" }
                    )
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (intent.getBooleanExtra(EXTRA_CONNECT, false)) connectRequest = true
    }

    override fun onStart() {
        super.onStart()
        if (!locked && awayTooLong()) locked = true
    }

    override fun onResume() {
        super.onResume()
        if (locked && !Auth.busy) promptUnlock()
    }

    override fun onStop() {
        super.onStop()
        if (!Auth.busy) settings.lastLeftAt = System.currentTimeMillis()
    }

    /** "Immediately" still tolerates ~1 s so a screen rotation does not lock the app. */
    private fun awayTooLong(): Boolean {
        if (!settings.appLock) return false
        val away = System.currentTimeMillis() - settings.lastLeftAt
        return away > settings.lockTimeoutSec * 1000L + 1000L
    }

    private fun promptUnlock() {
        if (!Auth.available(this)) {
            // The device lost its screen lock; fail open rather than lock the user out for good.
            settings.appLock = false
            locked = false
            Toast.makeText(this, R.string.lock_unavailable, Toast.LENGTH_LONG).show()
            return
        }
        Auth.prompt(this, getString(R.string.unlock_title), onOk = { locked = false })
    }

    /** Transparent system bars with icons that stay readable in the chosen theme. */
    private fun applyBars() {
        val dark = isDark(themeMode, (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES)
        val style = if (dark) SystemBarStyle.dark(Color.TRANSPARENT) else SystemBarStyle.light(Color.TRANSPARENT, Color.TRANSPARENT)
        enableEdgeToEdge(statusBarStyle = style, navigationBarStyle = style)
    }

    fun applySecureFlag() {
        if (settings.secureWindow) window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
    }

    companion object { const val EXTRA_CONNECT = "com.ghiat.vpn.CONNECT" }
}

@androidx.compose.runtime.Composable
private fun LockScreen(onUnlock: () -> Unit) {
    Column(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Image(painterResource(R.drawable.ic_logo), null, Modifier.size(96.dp))
        Spacer(Modifier.height(16.dp))
        Text(stringResource(R.string.locked), fontSize = 20.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.height(16.dp))
        Button(onClick = onUnlock) { Text(stringResource(R.string.unlock)) }
    }
}
