package com.ghiat.vpn.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ghiat.vpn.R
import com.ghiat.vpn.vpn.HistoryStore
import java.text.DateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HistoryScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    BackHandler(onBack = onBack)
    val store = remember { HistoryStore(context) }
    var items by remember { mutableStateOf(store.load()) }
    val fmt = remember { DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT) }

    LazyColumn(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)
            .statusBarsPadding().navigationBarsPadding().padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = onBack) { Text("←", fontSize = 22.sp) }
                Text(stringResource(R.string.history_title), fontSize = 22.sp, fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary, modifier = Modifier.weight(1f))
                if (items.isNotEmpty()) TextButton(onClick = { store.clear(); items = emptyList() }) {
                    Text(stringResource(R.string.history_clear))
                }
            }
        }
        if (items.isEmpty()) item { Text(stringResource(R.string.history_empty), color = Color.Gray) }
        itemsIndexed(items) { _, e ->
            SectionCard {
                Text(e.name.ifBlank { stringResource(R.string.app_name) }, fontWeight = FontWeight.SemiBold)
                Text(fmt.format(Date(e.start)), fontSize = 12.sp, color = Color.Gray)
                Text("${dur(e.seconds)}    ↓ ${bytes(e.rx)}    ↑ ${bytes(e.tx)}", fontSize = 13.sp)
            }
        }
        item { Spacer(Modifier.height(16.dp)) }
    }
}

private fun dur(s: Long) = String.format(Locale.US, "%02d:%02d:%02d", s / 3600, (s % 3600) / 60, s % 60)

private fun bytes(b: Long): String = when {
    b >= (1L shl 30) -> String.format(Locale.US, "%.2f GB", b / (1L shl 30).toDouble())
    b >= (1L shl 20) -> String.format(Locale.US, "%.1f MB", b / (1L shl 20).toDouble())
    b >= (1L shl 10) -> String.format(Locale.US, "%.0f KB", b / 1024.0)
    else -> "$b B"
}
