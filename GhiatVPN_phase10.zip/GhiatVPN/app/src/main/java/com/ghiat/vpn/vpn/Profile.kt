package com.ghiat.vpn.vpn

import androidx.annotation.StringRes
import com.ghiat.vpn.R

/** DNS servers written into the [Interface] section when connecting. */
enum class DnsOption(@StringRes val label: Int, val servers: String?) {
    DEFAULT(R.string.dns_default, null),
    CLOUDFLARE(R.string.dns_cloudflare, "1.1.1.1, 1.0.0.1"),
    GOOGLE(R.string.dns_google, "8.8.8.8, 8.8.4.4"),
    QUAD9(R.string.dns_quad9, "9.9.9.9, 149.112.112.112"),
    ADGUARD(R.string.dns_adguard, "94.140.14.14, 94.140.15.15"),
    CUSTOM(R.string.dns_custom, null)
}

/** OFF = every app uses the VPN, BYPASS = listed apps skip it, ONLY = only listed apps use it. */
enum class SplitMode(@StringRes val label: Int) {
    OFF(R.string.split_off),
    BYPASS(R.string.split_bypass),
    ONLY(R.string.split_only)
}

/** A saved server: the WireGuard config plus per-server DNS and split-tunnel choices. */
data class Profile(
    val id: String,
    val name: String,
    val flag: String,
    val conf: String,
    val dns: DnsOption = DnsOption.DEFAULT,
    val customDns: String = "",
    val splitMode: SplitMode = SplitMode.OFF,
    val apps: Set<String> = emptySet()
)
