package com.ghiat.vpn.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ghiat.vpn.R
import com.ghiat.vpn.vpn.AppEntry
import com.ghiat.vpn.vpn.Apps
import com.ghiat.vpn.vpn.ConfigBuilder
import com.ghiat.vpn.vpn.DnsOption
import com.ghiat.vpn.vpn.Preset
import com.ghiat.vpn.vpn.Presets
import com.ghiat.vpn.vpn.Profile
import com.ghiat.vpn.vpn.ServerStore
import com.ghiat.vpn.vpn.SplitMode
import com.ghiat.vpn.vpn.VpnController
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun ProfileEditorScreen(profileId: String, onDone: () -> Unit) {
    val context = LocalContext.current
    BackHandler(onBack = onDone)
    val store = remember { ServerStore(context) }
    val original = remember { store.load().firstOrNull { it.id == profileId } }
    if (original == null) {
        LaunchedEffect(Unit) { onDone() }
        return
    }
    EditorContent(original, store, onDone)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun EditorContent(original: Profile, store: ServerStore, onDone: () -> Unit) {
    val context = LocalContext.current
    var name by remember { mutableStateOf(original.name) }
    var flag by remember { mutableStateOf(original.flag) }
    var dns by remember { mutableStateOf(original.dns) }
    var customDns by remember { mutableStateOf(original.customDns) }
    var split by remember { mutableStateOf(original.splitMode) }
    var apps by remember { mutableStateOf(original.apps) }
    var conf by remember { mutableStateOf(original.conf) }
    var showConf by remember { mutableStateOf(false) }
    var err by remember { mutableStateOf<String?>(null) }
    var info by remember { mutableStateOf<String?>(null) }
    var query by remember { mutableStateOf("") }
    var allApps by remember { mutableStateOf<List<AppEntry>?>(null) }
    LaunchedEffect(Unit) { allApps = withContext(Dispatchers.IO) { Apps.launcherApps(context) } }
    val shown = allApps?.filter { query.isBlank() || it.label.contains(query, true) || it.pkg.contains(query, true) }

    fun applyPreset(p: Preset) {
        info = null
        p.dns?.let { dns = it }
        val mode = p.split ?: return
        if (mode == SplitMode.OFF) { split = SplitMode.OFF; apps = emptySet(); return }
        val installed = allApps?.map { it.pkg }?.toSet() ?: emptySet()
        val found = p.packages.filter { it in installed }.toSet()
        if (found.isEmpty()) { info = context.getString(R.string.preset_none_installed); return }
        split = mode; apps = found
    }

    fun save() {
        val p = Profile(original.id, name.ifBlank { "Server" }, flag.ifBlank { "🌐" }, conf, dns, customDns.trim(), split, apps)
        if (dns == DnsOption.CUSTOM && !ConfigBuilder.validDnsList(customDns)) {
            err = context.getString(R.string.dns_invalid); return
        }
        if (split == SplitMode.ONLY && apps.isEmpty()) {
            err = context.getString(R.string.split_only_empty); return
        }
        try { VpnController.validate(ConfigBuilder.build(p)) }
        catch (e: Exception) { err = context.getString(R.string.invalid_config) + ": " + (e.message ?: ""); return }
        store.save(store.load().map { if (it.id == p.id) p else it })
        onDone()
    }

    LazyColumn(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)
            .statusBarsPadding().navigationBarsPadding().padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = onDone) { Text("←", fontSize = 22.sp) }
                Text(stringResource(R.string.edit_server), fontSize = 22.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, modifier = Modifier.weight(1f))
                TextButton(onClick = { save() }) { Text(stringResource(R.string.save)) }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, singleLine = true, modifier = Modifier.weight(1f), label = { Text(stringResource(R.string.server_name)) })
                OutlinedTextField(flag, { flag = it.take(8) }, singleLine = true, modifier = Modifier.width(96.dp), label = { Text(stringResource(R.string.server_flag)) })
            }
        }
        item {
            Text(stringResource(R.string.presets_title), fontWeight = FontWeight.Bold)
            Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Presets.all.forEach { p -> AssistChip(onClick = { applyPreset(p) }, label = { Text(stringResource(p.label)) }) }
            }
            info?.let { Text(it, fontSize = 12.sp, color = Color(0xFFC62828)) }
        }
        item {
            Text(stringResource(R.string.dns_title), fontWeight = FontWeight.Bold)
            Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                DnsOption.values().forEach { o ->
                    FilterChip(selected = dns == o, onClick = { dns = o }, label = { Text(stringResource(o.label)) })
                }
            }
            if (dns == DnsOption.CUSTOM) {
                OutlinedTextField(
                    customDns, { customDns = it }, modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
                    label = { Text(stringResource(R.string.dns_custom_hint)) }
                )
            }
        }
        item {
            Text(stringResource(R.string.split_title), fontWeight = FontWeight.Bold)
            Row(Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SplitMode.values().forEach { m ->
                    FilterChip(
                        selected = split == m, modifier = Modifier.weight(1f),
                        onClick = { split = m; if (m == SplitMode.OFF) apps = emptySet() },
                        label = { Text(stringResource(m.label), maxLines = 1) }
                    )
                }
            }
            when (split) {
                SplitMode.BYPASS -> Text(stringResource(R.string.split_bypass_desc), fontSize = 12.sp, color = Color.Gray)
                SplitMode.ONLY -> Text(stringResource(R.string.split_only_desc), fontSize = 12.sp, color = Color.Gray)
                SplitMode.OFF -> Text(stringResource(R.string.split_desc), fontSize = 12.sp, color = Color.Gray)
            }
            if (split != SplitMode.OFF) {
                Text(stringResource(R.string.apps_selected, apps.size), fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                OutlinedTextField(
                    query, { query = it }, singleLine = true,
                    modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                    label = { Text(stringResource(R.string.search_apps)) }
                )
            }
        }
        if (split != SplitMode.OFF) {
            appItems(shown, apps) { pkg, on -> apps = if (on) apps + pkg else apps - pkg }
        }
        item {
            TextButton(onClick = { showConf = !showConf }) {
                Text(stringResource(if (showConf) R.string.hide_config else R.string.show_config))
            }
            if (showConf) {
                OutlinedTextField(conf, { conf = it }, modifier = Modifier.fillMaxWidth(), minLines = 6, maxLines = 14,
                    label = { Text(stringResource(R.string.config_label)) })
            }
            err?.let { Text(it, color = Color(0xFFC62828), fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp)) }
            Spacer(Modifier.height(24.dp))
        }
    }
}
