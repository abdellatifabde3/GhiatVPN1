package com.ghiat.vpn.ui

import android.app.Activity
import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import android.widget.Toast
import android.net.VpnService
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ghiat.vpn.R
import com.ghiat.vpn.vpn.AppSettings
import com.ghiat.vpn.vpn.ConnectionManager
import com.ghiat.vpn.vpn.DnsOption
import com.ghiat.vpn.vpn.LatencyTester
import com.ghiat.vpn.vpn.Profile
import com.ghiat.vpn.vpn.ServerStore
import com.ghiat.vpn.vpn.SplitMode
import com.ghiat.vpn.vpn.VpnController
import com.ghiat.vpn.vpn.VpnState
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.codescanner.GmsBarcodeScannerOptions
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning
import kotlinx.coroutines.launch
import java.util.Locale
import java.util.UUID

private val Green = Color(0xFF2E7D32)

@Composable
fun HomeScreen(
    autoConnect: Boolean = false,
    onAutoConnectHandled: () -> Unit = {},
    onOpenSettings: () -> Unit = {},
    onOpenPrivacy: () -> Unit = {},
    onEdit: (String) -> Unit = {}
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val settings = remember { AppSettings(context) }
    val store = remember { ServerStore(context) }
    val servers = remember { mutableStateListOf<Profile>().apply { addAll(store.load()) } }
    var selectedId by remember {
        mutableStateOf(settings.selectedId?.takeIf { id -> servers.any { it.id == id } } ?: servers.firstOrNull()?.id)
    }
    var autoPick by remember { mutableStateOf(settings.autoPick) }
    var showAdd by rememberSaveable { mutableStateOf(false) }
    val latencies = remember { mutableStateMapOf<String, Long?>() }
    var testing by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { VpnController.refresh(context) }
    val state by VpnController.state.collectAsState()
    val error by VpnController.error.collectAsState()
    val stats by VpnController.stats.collectAsState()
    val activeName by VpnController.activeName.collectAsState()

    fun startVpn() { scope.launch { ConnectionManager.connectSelected(context) } }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (it.resultCode == Activity.RESULT_OK) startVpn()
    }
    fun requestConnect() {
        if (servers.isEmpty()) { showAdd = true; return }
        val intent = VpnService.prepare(context)
        if (intent != null) permLauncher.launch(intent) else startVpn()
    }
    LaunchedEffect(autoConnect) {
        if (autoConnect) {
            onAutoConnectHandled()
            if (state == VpnState.DISCONNECTED) requestConnect()
        }
    }
    fun testAll() {
        if (testing || servers.isEmpty()) return
        testing = true
        latencies.clear()
        scope.launch {
            val r = LatencyTester.testAll(servers.toList())
            latencies.putAll(r)
            testing = false
        }
    }
    val fastestId = latencies.filterValues { it != null }.minByOrNull { it.value!! }?.key

    Column(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)
            .statusBarsPadding().navigationBarsPadding().padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Image(painterResource(R.drawable.ic_logo), null, Modifier.size(44.dp))
            Spacer(Modifier.width(8.dp))
            Text(stringResource(R.string.app_name), fontSize = 24.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, modifier = Modifier.weight(1f))
            Text("🛡", fontSize = 24.sp, color = MaterialTheme.colorScheme.primary, modifier = Modifier.clickable { onOpenPrivacy() }.padding(8.dp))
            Text("⚙", fontSize = 26.sp, color = MaterialTheme.colorScheme.primary, modifier = Modifier.clickable { onOpenSettings() }.padding(8.dp))
        }
        Spacer(Modifier.weight(1f))

        val ring by animateColorAsState(
            when (state) { VpnState.CONNECTED -> Green; VpnState.CONNECTING -> BlueLight; else -> Blue }, label = "ring"
        )
        Box(
            Modifier.size(180.dp).clip(CircleShape).border(8.dp, ring, CircleShape).background(MaterialTheme.colorScheme.surface)
                .clickable {
                    when (state) {
                        VpnState.DISCONNECTED -> requestConnect()
                        VpnState.CONNECTED -> ConnectionManager.disconnectByUser(context)
                        VpnState.CONNECTING -> Unit
                    }
                },
            contentAlignment = Alignment.Center
        ) { Icon(painterResource(R.drawable.ic_power), null, Modifier.size(72.dp), tint = ring) }

        Spacer(Modifier.height(16.dp))
        Text(
            stringResource(
                when (state) {
                    VpnState.DISCONNECTED -> R.string.tap_connect
                    VpnState.CONNECTING -> R.string.connecting
                    VpnState.CONNECTED -> R.string.connected
                }
            ),
            fontSize = 20.sp, fontWeight = FontWeight.SemiBold, color = ring
        )
        if (state == VpnState.CONNECTED) {
            activeName?.let { Text(it, fontSize = 14.sp, color = MaterialTheme.colorScheme.primary) }
            Text(stringResource(R.string.tap_disconnect), fontSize = 13.sp, color = Color.Gray)
            Spacer(Modifier.height(10.dp))
            Text(formatDuration(stats.seconds), fontSize = 16.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.primary)
            Text("↓ ${formatSpeed(stats.rxSpeed)}    ↑ ${formatSpeed(stats.txSpeed)}", fontSize = 14.sp)
            Text("↓ ${formatBytes(stats.rx)}    ↑ ${formatBytes(stats.tx)}", fontSize = 12.sp, color = Color.Gray)
        }
        error?.let { Text(it, fontSize = 12.sp, color = Color(0xFFC62828), modifier = Modifier.padding(top = 6.dp)) }
        Spacer(Modifier.weight(1f))

        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(stringResource(R.string.choose_server), fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            TextButton(onClick = { testAll() }, enabled = state == VpnState.DISCONNECTED && !testing && servers.isNotEmpty()) {
                Text(stringResource(if (testing) R.string.testing else R.string.test_servers))
            }
            TextButton(onClick = { showAdd = true }, enabled = state == VpnState.DISCONNECTED) {
                Text("+ " + stringResource(R.string.add_server))
            }
        }
        if (servers.isEmpty()) {
            Text(stringResource(R.string.no_servers), color = Color.Gray, fontSize = 13.sp, modifier = Modifier.padding(vertical = 12.dp))
        }
        LazyColumn(Modifier.heightIn(max = 260.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (servers.size > 1) item {
                val sel = autoPick
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
                        .background(if (sel) Blue.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surface)
                        .border(1.dp, if (sel) Blue else Color(0xFFE0E6F0), RoundedCornerShape(14.dp))
                        .clickable(enabled = state == VpnState.DISCONNECTED) {
                            autoPick = true; settings.autoPick = true
                        }
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("⚡", fontSize = 26.sp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(stringResource(R.string.auto_server), fontWeight = FontWeight.SemiBold)
                        Text(stringResource(R.string.auto_server_desc), fontSize = 11.sp, color = Color.Gray)
                    }
                }
            }
            items(servers, key = { it.id }) { s ->
                val sel = s.id == selectedId && !(autoPick && servers.size > 1)
                val tested = latencies.containsKey(s.id)
                val ms = latencies[s.id]
                val isFastest = s.id == fastestId
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
                        .background(if (sel) Blue.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surface)
                        .border(if (isFastest) 2.dp else 1.dp, if (isFastest) Green else if (sel) Blue else Color(0xFFE0E6F0), RoundedCornerShape(14.dp))
                        .clickable(enabled = state == VpnState.DISCONNECTED) {
                            selectedId = s.id; autoPick = false
                            settings.selectedId = s.id; settings.autoPick = false
                        }
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(s.flag, fontSize = 26.sp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(s.name, fontWeight = FontWeight.SemiBold)
                        val summary = listOfNotNull(
                            if (s.dns != DnsOption.DEFAULT) stringResource(s.dns.label) else null,
                            if (s.splitMode != SplitMode.OFF) stringResource(R.string.profile_summary_apps, stringResource(s.splitMode.label), s.apps.size) else null
                        ).joinToString(" • ")
                        if (summary.isNotEmpty()) Text(summary, fontSize = 11.sp, color = Color.Gray)
                    }
                    if (tested) {
                        Text(
                            (if (isFastest) "⚡ " else "") + (ms?.let { "$it ms" } ?: "—"),
                            fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = if (isFastest) Green else Color.Gray
                        )
                    }
                    if (state == VpnState.DISCONNECTED) {
                        Text("✎", color = MaterialTheme.colorScheme.primary, fontSize = 18.sp, modifier = Modifier.clickable { onEdit(s.id) }.padding(8.dp))
                        Text("✕", color = Color.Gray, modifier = Modifier.clickable {
                            servers.remove(s); store.save(servers.toList())
                            if (selectedId == s.id) { selectedId = servers.firstOrNull()?.id; settings.selectedId = selectedId }
                        }.padding(8.dp))
                    }
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        Text(stringResource(R.string.developer), fontSize = 12.sp, color = Color.Gray)
    }

    if (showAdd) {
        AddServerDialog(
            onDismiss = { showAdd = false },
            onAddMany = { list ->
                servers.addAll(list); store.save(servers.toList())
                if (selectedId == null) { selectedId = list.first().id; settings.selectedId = selectedId }
                showAdd = false
            },
            onAdd = { p ->
                servers.add(p); store.save(servers.toList())
                if (selectedId == null) { selectedId = p.id; settings.selectedId = p.id }
                showAdd = false
            }
        )
    }
}

@Composable
private fun AddServerDialog(onDismiss: () -> Unit, onAdd: (Profile) -> Unit, onAddMany: (List<Profile>) -> Unit) {
    val context = LocalContext.current
    var name by remember { mutableStateOf("") }
    var conf by remember { mutableStateOf("") }
    var err by remember { mutableStateOf<String?>(null) }
    val clipboard = LocalClipboardManager.current
    val scan = {
        val opts = GmsBarcodeScannerOptions.Builder().setBarcodeFormats(Barcode.FORMAT_QR_CODE).build()
        GmsBarcodeScanning.getClient(context, opts).startScan()
            .addOnSuccessListener { b ->
                val text = b.rawValue
                if (text.isNullOrBlank()) err = context.getString(R.string.scan_failed)
                else { conf = text; err = null; if (name.isBlank()) name = "Server" }
            }
            .addOnFailureListener { err = context.getString(R.string.scan_failed) }
        Unit
    }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) try {
            conf = context.contentResolver.openInputStream(uri)!!.use { it.readBytes().toString(Charsets.UTF_8) }
            if (name.isBlank()) name = "Server"
            err = null
        } catch (e: Exception) { err = context.getString(R.string.invalid_config) }
    }
    val multi = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        val list = mutableListOf<Profile>()
        uris.forEach { uri ->
            try {
                val text = context.contentResolver.openInputStream(uri)!!.use { it.readBytes().toString(Charsets.UTF_8) }
                VpnController.validate(text)
                list.add(Profile(UUID.randomUUID().toString(), displayName(context, uri), "🌐", text))
            } catch (_: Exception) {}
        }
        if (uris.isNotEmpty()) {
            Toast.makeText(context, context.getString(R.string.import_result, list.size, uris.size - list.size), Toast.LENGTH_LONG).show()
        }
        if (list.isNotEmpty()) onAddMany(list)
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.add_server)) },
        text = {
            Column {
                OutlinedTextField(name, { name = it }, singleLine = true, label = { Text(stringResource(R.string.server_name)) })
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(conf, { conf = it }, label = { Text(stringResource(R.string.paste_config)) }, minLines = 5, maxLines = 8)
                Row {
                    TextButton(onClick = { picker.launch("*/*") }) { Text(stringResource(R.string.import_file)) }
                    TextButton(onClick = {
                        val t = clipboard.getText()?.text
                        if (t.isNullOrBlank()) err = context.getString(R.string.clipboard_empty)
                        else { conf = t; err = null; if (name.isBlank()) name = "Server" }
                    }) { Text(stringResource(R.string.paste_clipboard)) }
                }
                TextButton(onClick = { scan() }) { Text(stringResource(R.string.scan_qr)) }
                TextButton(onClick = { multi.launch(arrayOf("*/*")) }) { Text(stringResource(R.string.import_many)) }
                err?.let { Text(it, color = Color(0xFFC62828), fontSize = 12.sp) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                try {
                    VpnController.validate(conf)
                    onAdd(Profile(UUID.randomUUID().toString(), name.ifBlank { "Server" }, "🌐", conf))
                } catch (e: Exception) { err = context.getString(R.string.invalid_config) + ": " + (e.message ?: "") }
            }) { Text(stringResource(R.string.save)) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) } }
    )
}

/** File name without the .conf extension, used as the server name. */
private fun displayName(context: Context, uri: Uri): String {
    val name = try {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) it.getString(0) else null
        }
    } catch (_: Exception) { null }
    return (name ?: "Server").removeSuffix(".conf").ifBlank { "Server" }
}

private fun formatBytes(b: Long): String = when {
    b >= (1L shl 30) -> String.format(Locale.US, "%.2f GB", b / (1L shl 30).toDouble())
    b >= (1L shl 20) -> String.format(Locale.US, "%.1f MB", b / (1L shl 20).toDouble())
    b >= (1L shl 10) -> String.format(Locale.US, "%.0f KB", b / 1024.0)
    else -> "$b B"
}

private fun formatSpeed(b: Long) = formatBytes(b) + "/s"

private fun formatDuration(s: Long) = String.format(Locale.US, "%02d:%02d:%02d", s / 3600, (s % 3600) / 60, s % 60)
