package com.ghiat.vpn

import android.app.Application
import com.ghiat.vpn.vpn.VpnController

class GhiatApp : Application() {
    override fun onCreate() {
        super.onCreate()
        VpnController.attach(this)
    }
}
