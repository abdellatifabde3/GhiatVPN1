package com.ghiat.vpn.notify

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.ghiat.vpn.MainActivity
import com.ghiat.vpn.R
import com.ghiat.vpn.vpn.AppSettings
import com.ghiat.vpn.vpn.ConnectionManager
import com.ghiat.vpn.vpn.VpnState

/** Optional ongoing notification while connected. Shown only if the user enabled it and allowed notifications. */
object Notifier {
    private const val CHANNEL = "status"
    private const val ID = 1

    fun granted(ctx: Context): Boolean =
        Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    fun update(ctx: Context, state: VpnState, name: String?) {
        val app = ctx.applicationContext
        val nm = NotificationManagerCompat.from(app)
        if (state != VpnState.CONNECTED || !AppSettings(app).notify || !granted(app)) {
            nm.cancel(ID); return
        }
        app.getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel(CHANNEL, app.getString(R.string.notif_channel), NotificationManager.IMPORTANCE_LOW)
        )
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val open = PendingIntent.getActivity(app, 3, Intent(app, MainActivity::class.java), flags)
        val off = PendingIntent.getBroadcast(app, 4, Intent(app, DisconnectReceiver::class.java), flags)
        val n = NotificationCompat.Builder(app, CHANNEL)
            .setSmallIcon(R.drawable.ic_power)
            .setContentTitle(app.getString(R.string.app_name))
            .setContentText(app.getString(R.string.connected) + (name?.let { " • $it" } ?: ""))
            .setOngoing(true).setOnlyAlertOnce(true).setContentIntent(open)
            .addAction(0, app.getString(R.string.disconnect), off)
            .build()
        try { nm.notify(ID, n) } catch (_: SecurityException) {}
    }
}

class DisconnectReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) { ConnectionManager.disconnectByUser(context) }
}
