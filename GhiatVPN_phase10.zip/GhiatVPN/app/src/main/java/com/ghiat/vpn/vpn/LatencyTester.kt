package com.ghiat.vpn.vpn

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import java.util.concurrent.TimeUnit

/** Measures ICMP round-trip time to a server. Only meaningful while the VPN is disconnected. */
object LatencyTester {
    // Reject anything that could be read as a command-line option or contains odd characters.
    private val SAFE_HOST = Regex("^[A-Za-z0-9][A-Za-z0-9.:\\-]*$")
    private val TIME = Regex("time[=<]\\s*([0-9]+(?:\\.[0-9]+)?)")

    /** Milliseconds, or null if unreachable / ICMP blocked. */
    suspend fun ping(host: String): Long? = withContext(Dispatchers.IO) {
        if (!SAFE_HOST.matches(host)) return@withContext null
        try {
            val bin = if (host.contains(':')) "ping6" else "ping"
            val p = ProcessBuilder(bin, "-c", "1", "-W", "2", host).redirectErrorStream(true).start()
            if (!p.waitFor(4, TimeUnit.SECONDS)) { p.destroyForcibly(); return@withContext null }
            val out = p.inputStream.bufferedReader().readText()
            val ms = TIME.find(out)?.groupValues?.get(1)?.toDoubleOrNull() ?: return@withContext null
            Math.round(ms).coerceAtLeast(1L)
        } catch (_: Exception) { null }
    }

    suspend fun testAll(profiles: List<Profile>): Map<String, Long?> = coroutineScope {
        profiles.map { p ->
            async { p.id to ConfigBuilder.endpointHost(p.conf)?.let { ping(it) } }
        }.awaitAll().toMap()
    }
}
