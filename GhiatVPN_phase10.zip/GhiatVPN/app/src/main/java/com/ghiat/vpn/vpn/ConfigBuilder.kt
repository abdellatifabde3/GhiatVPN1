package com.ghiat.vpn.vpn

/** Turns a Profile into the final WireGuard config text and reads facts out of a config. */
object ConfigBuilder {

    fun build(p: Profile): String {
        val dns: String? = when (p.dns) {
            DnsOption.DEFAULT -> null
            DnsOption.CUSTOM -> p.customDns.trim().takeIf { it.isNotEmpty() }?.let { normalizeDns(it) }
            else -> p.dns.servers
        }
        val split: String? = when {
            p.apps.isEmpty() -> null
            p.splitMode == SplitMode.BYPASS -> "ExcludedApplications = " + p.apps.sorted().joinToString(", ")
            p.splitMode == SplitMode.ONLY -> "IncludedApplications = " + p.apps.sorted().joinToString(", ")
            else -> null
        }
        return editInterface(p.conf, dns?.let { "DNS = $it" }, split)
    }

    private fun key(line: String) = line.trim().substringBefore('=').trim().lowercase()

    private fun editInterface(conf: String, dnsLine: String?, splitLine: String?): String {
        if (dnsLine == null && splitLine == null) return conf
        val lines = conf.lines()
        val start = lines.indexOfFirst { it.trim().equals("[Interface]", ignoreCase = true) }
        if (start < 0) return conf
        var end = lines.size
        for (i in start + 1 until lines.size) {
            if (lines[i].trim().startsWith("[")) { end = i; break }
        }
        val kept = lines.subList(start + 1, end).filterNot { l ->
            val k = key(l)
            (dnsLine != null && k == "dns") ||
                (splitLine != null && (k == "excludedapplications" || k == "includedapplications"))
        }
        val out = lines.subList(0, start + 1) + listOfNotNull(dnsLine, splitLine) + kept + lines.subList(end, lines.size)
        return out.joinToString("\n")
    }

    fun normalizeDns(raw: String): String =
        raw.split(',', ' ', ';', '\n').map { it.trim() }.filter { it.isNotEmpty() }.joinToString(", ")

    fun validDnsList(raw: String): Boolean {
        val items = normalizeDns(raw).split(", ").filter { it.isNotEmpty() }
        return items.isNotEmpty() && items.all { isIpv4(it) || isIpv6(it) }
    }

    private fun isIpv4(s: String): Boolean {
        val parts = s.split('.')
        return parts.size == 4 && parts.all { p -> p.isNotEmpty() && p.length <= 3 && p.all { it.isDigit() } && p.toInt() <= 255 }
    }

    private fun isIpv6(s: String): Boolean =
        s.contains(':') && s.length >= 2 && s.all { it.isDigit() || it in 'a'..'f' || it in 'A'..'F' || it == ':' || it == '.' }

    /** Host part of the first Endpoint line (IPv4, IPv6 in brackets, or a hostname). */
    fun endpointHost(conf: String): String? {
        val value = conf.lines().firstOrNull { key(it) == "endpoint" }
            ?.substringAfter('=', "")?.trim().orEmpty()
        if (value.isEmpty()) return null
        return if (value.startsWith("[")) value.substringAfter('[').substringBefore(']')
        else value.substringBeforeLast(':').ifEmpty { null }
    }

    /** Every AllowedIPs entry of every peer. */
    fun allowedIps(conf: String): List<String> =
        conf.lines().filter { key(it) == "allowedips" }
            .flatMap { it.substringAfter('=', "").split(',') }
            .map { it.trim() }.filter { it.isNotEmpty() }

    fun hasDns(conf: String): Boolean =
        conf.lines().any { key(it) == "dns" && it.substringAfter('=', "").isNotBlank() }
}
