# GhiatVPN - Phase 10
1. Install Android Studio (latest), then File > Open > select the GhiatVPN folder.
2. Wait for Gradle sync (needs internet the first time).
3. Plug in your phone (USB debugging on) and press Run, or Build > Build APK(s).
4. For Play Store: see store/PLAY_STORE_GUIDE.md.

Phase 5: Keystore-encrypted configs, no cloud backup, .conf import / clipboard paste, state re-sync.
Phase 6: QR scan, kill switch shortcut, split tunneling, live speed / traffic / duration stats.
Phase 8 (v1.2.0):
- Per-server profiles: DNS (Cloudflare / Google / Quad9 / AdGuard / custom) and split tunneling
  (all apps / bypass the VPN / only these apps), with quick templates. The old global bypass list is
  migrated into your servers on first launch.
- Server latency test (ICMP ping, only while disconnected), fastest server highlighted, "Auto" mode
  that connects to the fastest server.
- Auto-connect (off / on Wi-Fi / on any network) and auto-reconnect after reboot, with no location
  permission. Networks that still need a login (captive portals) are ignored.
- Quick Settings tile and home screen widget.
- App lock (fingerprint / face / screen lock) with timing options, and hide-in-recents / block screenshots.
- Privacy check: IPv4 / IPv6 / DNS / split-tunnel configuration checks and an optional IP + country check.
Phase 9 (v1.3.0):
- Dark theme (system / light / dark).
- Optional connection history (off by default): time, server name, duration and data only; clearable.
- Optional status notification while connected, with a Disconnect button (asks for the notification
  permission on Android 13+ only when you turn it on).
Phase 10 (v1.4.0):
- Password-protected backup: export all servers to a .gvpn file and restore them on another phone
  (AES-256-GCM, key from PBKDF2-HMAC-SHA256). Restoring adds servers; existing ones are kept. A forgotten
  password cannot be recovered. The file contains your private keys: store it safely.
- Import several .conf files at once (each file becomes a server named after the file; invalid files are skipped).

## Auto-connect rules
The app cannot read the Wi-Fi name without location permission, so rules use the network type.
Connect when: not already connected, a non-VPN network has validated internet (not a captive portal),
the VPN permission was already granted, and EITHER the type matches the chosen mode and you did not
disconnect by hand on this network, OR "Reconnect automatically" is on and the VPN was up when the
device restarted / the attempt failed. A manual disconnect pauses auto-connect until the matching
network is lost and a new one appears. If the system or another VPN app turns the tunnel off, the
app does not fight it. Quick tile / widget start the VPN only when the permission and a server exist.
