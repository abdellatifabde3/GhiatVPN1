# Publishing GhiatVPN – checklist

1. **Sign**: keytool -genkey -v -keystore ghiatvpn.jks -keyalg RSA -keysize 2048 -validity 10000 -alias ghiat
   Put ghiatvpn.jks in the project root, copy keystore.properties.example to keystore.properties and fill it.
   BACK UP the .jks and passwords: if lost you can never update the app.
2. **Build**: Android Studio > Build > Generate Signed Bundle (AAB) > release.
3. **Target API**: already 36 (required for new apps since 2026-08-31). Accept Android Studio's Gradle/AGP upgrade prompt.
4. **Developer account**: one-time 25 USD fee at play.google.com/console, with identity verification.
5. **Privacy policy**: fill [YOUR_EMAIL] and [DATE] in store/privacy_policy.html, host it (e.g. GitHub Pages) and paste the URL in Play Console.
6. **VPN rules**: declare the VpnService permission in Play Console (App content > VPN service form). VPN must be the app's core function, must not collect personal data beyond what's disclosed, and must not be used for ads or traffic manipulation.
7. **App review**: reviewers must be able to connect. Add test server config / instructions in "App access" notes.
8. **Data safety form**: answer "no data collected / shared" (matches the policy) and keep it truthful.
9. **Content rating** questionnaire, then listing text from STORE_LISTING.md, then testing track before production (new personal accounts need a closed test first).

10. **Optional features disclosure**: split tunneling uses a `<queries>` launcher intent (no QUERY_ALL_PACKAGES needed). QR scanning uses Google code scanner (no CAMERA permission). Keep the privacy policy text as is.
11. **versionCode** must increase for every upload (now 5 / 1.4.0).
12. **Release build** now uses R8 (code shrinking, obfuscation, resource shrinking) and ships native debug symbols. After the first signed AAB, upload `app/build/outputs/mapping/release/mapping.txt` in Play Console (App bundle explorer > your release > Downloads > or on the release page) so crash reports are readable. Test the release build on a real device (connect, disconnect, add server, QR, split tunneling) before uploading.
13. **Notifications**: POST_NOTIFICATIONS is requested only when the user turns on the optional status notification (Android 13+). It is a runtime permission, nothing to declare in Play Console.
14. **New permissions (all normal, no declaration form)**: ACCESS_NETWORK_STATE (auto-connect), RECEIVE_BOOT_COMPLETED (re-arm auto-connect after restart), USE_BIOMETRIC (app lock). No location, no QUERY_ALL_PACKAGES.
15. **Privacy check**: when the user taps "Check now" the app requests https://www.cloudflare.com/cdn-cgi/trace (the user's IP is visible to Cloudflare like any web request). Nothing is sent otherwise, nothing is stored. Keep the privacy policy section "Optional features" as updated, and answer the Data safety form consistently (no data collected by the developer).
16. **Test on a real device before upload**: tile, widget, auto-connect after reboot, app lock, ping test (servers that block ICMP show a dash).
17. **Connection history** is off by default and stored only on the device (time, server name, duration, data). Mention it in the Data safety notes as on-device only; it is already covered by the privacy policy.
18. **Backup / import** use the system file picker (no storage permission). Backups are encrypted on the device and never uploaded by the app.
